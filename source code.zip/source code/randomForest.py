{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# 课前准备\n",
    "\n",
    "> 本节课提前需要回顾决策树算法，以及随机森林在内的机器学习集成算法。\n",
    "\n",
    "# 课堂主题\n",
    "\n",
    "> 随机森林的Python代码实践；\n",
    "> 辅以其他的集成算法（XGBoost/LightGBM）的Python代码实践。\n",
    "\n",
    "# 课堂目标\n",
    "\n",
    "> 本节课的目标是理解如何使用Python实现随机森林模型的训练与预测。\n",
    "\n",
    "1. 理解Python做随机森林的步骤\n",
    "2. 掌握使用Python做用户流失预测\n"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# 算法概述"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "sklearn.ensemble.RandomForestClassifier(n_estimators=10, criterion='gini', max_depth=None, min_samples_split=2, min_samples_leaf=1,\n",
    " min_weight_fraction_leaf=0.0, max_features='auto', max_leaf_nodes=None, min_impurity_split=1e-07, bootstrap=True, oob_score=False, n_jobs=1, random_state=None, verbose=0, warm_start=False, class_weight=None)\n",
    "\n",
    "## 参数解读\n",
    "\n",
    "Bagging框架的参数和GBDT对比，GBDT的框架参数比较多，重要的有最大迭代器的个数，步长和子采样的比例等，调参过程比较费力。但是基于Bagging框架的随机森林则比较简单，这是因为Bagging的各个弱学习器之间是没有依赖关系的，降低了调参的难度。换句话说，达到同样的调参效果，随机森林调参时间要比GBDT少一些。\n",
    "\n",
    "下面我们来看看随机森林的重要参数，由于Random Forest Classifier和Random Forest Regressor参数绝大部分相同，这里会将它们一起讲，不同点会指出。\n",
    "\n",
    "  - n_estimators: 也就是弱学习器的最大迭代次数，或者说最大的决策树个数，默认是10。一般来说n_estimators太小，容易欠拟合，n_estimators太大，又容易过拟合，一般选择一个适中的数值。\n",
    "\n",
    "  - bootstrap：默认True，是否有放回的采样。\n",
    "  \n",
    "  \n",
    "  - oob_score：默认识False，即是否采用袋外样本来评估模型的好坏。有放回采样中大约会有36.8%的数据没有被采样到，我们常常称之为袋外数据(Out Of Bag, 简称OOB)，这些数据没有参与到训练集模型的拟合，因此可以用来检测模型的泛化能力。推荐设置为True，因为袋外分数反应了模型拟合后的泛化能力。对单个模型的参数训练，我们知道可以用cross validation（cv）来进行，但是比较消耗时间，而且对于随机森林这种情况没有太大的必要，所以就用袋外数据对决策树模型进行验证，类似一个简单的交叉验证，性能消耗小，但是效果不错。\n",
    "  \n",
    "  \n",
    "  - criterion：\n",
    " 即CART树做划分时对特征的评价标准，分类模型和回归模型的损失函数是不一样的。\n",
    " \n",
    "  （1）分类RF对应的CART分类树默认是基尼系数gini,另一个可选择的标准是信息增益entropy，是用来选择节点的最优特征和切分点的两个准则。\n",
    "\n",
    "  （2）回归RF对应的CART回归树默认是均方差MSE，另一个可选择的标准是绝对值误差MAE。一般来说选择默认的标准就已经很好的。\n",
    "  \n",
    "\n",
    "  - max_features: 随机森林划分时考虑的最大特征数。可以使用很多种类型的值，默认是\"None\",意味着划分时考虑所有的特征数；如果是\"log2\"意味着划分时最多考虑log2N个特征；如果是\"sqrt\"或者\"auto\"意味着划分时最多考虑N−−√N个特征。如果是整数，代表考虑的特征绝对数。如果是浮点数，代表考虑特征百分比，即考虑（百分比xN）取整后的特征数，其中N为样本总特征数。一般来说，如果样本特征数不多，比如小于50，我们用默认的\"None\"就可以了，如果特征数非常多，我们可以灵活使用刚才描述的其他取值来控制划分时考虑的最大特征数，以控制决策树的生成时间。\n",
    "  \n",
    "  \n",
    "  - max_depth:\n",
    "决策树最大深度。默认为\"None\"，即不限制子树的深度。这样建树时，会使每一个叶节点只有一个类别，或是达到min_samples_split。一般来说，数据少或者特征少的时候可以不管这个值。如果模型样本量多，特征也多的情况下，推荐限制这个最大深度，具体的取值取决于数据的分布。常用的可以取值10-100之间。\n",
    "\n",
    "\n",
    "  - min_samples_split:\n",
    "内部节点再划分所需的最小样本数，默认2。这个值限制了子树继续划分的条件，如果某节点的样本数小于min_samples_split，则不会继续划分。如果样本量不大，可以不设置这个值；如果样本量数量级非常大，则推荐增大这个值。\n",
    "\n",
    "\n",
    "  - min_samples_leaf: 叶子节点最少样本数。\n",
    "这个值限制了叶子节点的最小样本数，如果某个叶子节点的样本数小于min_samples_leaf，则会和兄弟节点一起被剪枝。默认是1，可以输入最少的样本数的整数，或者最少样本数占样本总数的百分比。如果样本量不大，不需要管这个值。如果样本量数量级非常大，则推荐增大这个值。\n",
    "\n",
    "\n",
    "  - min_weight_fraction_leaf: 叶子节点最小的样本权重和。这个值限制了叶子节点所有样本权重和的最小值，如果小于这个值，则会和兄弟节点一起被剪枝。\n",
    "默认是0，就是不考虑权重问题。一般来说，如果我们有较多样本有缺失值，或者分类树样本的分布类别偏差很大，就会引入样本权重，这时我们就要注意这个值了。\n",
    "\n",
    "\n",
    "  - max_leaf_nodes: \n",
    "最大叶子节点数。通过限制最大叶子节点数，可以防止过拟合。默认是\"None”，即不限制最大的叶子节点数。如果加了限制，算法会建立在最大叶子节点数内最优的决策树。如果特征不多，可以不考虑这个值，但是如果特征分成多的话，可以加以限制，具体的值可以通过交叉验证得到。\n",
    "\n",
    "\n",
    "  - min_impurity_split: \n",
    "节点划分最小不纯度。这个值限制了决策树的增长，如果某节点的不纯度(基于基尼系数，均方差)小于这个阈值，则该节点不再生成子节点，即为叶子节点。一般不推荐改动默认值1e-7。\n",
    "\n",
    "\n",
    "  - splitter: \n",
    "随机选择属性\"random\"还是选择不纯度最大\"best\"的属性，建议用默认best。\n",
    "\n",
    "\n",
    "  - presort: 是否对数据进行预分类，以加快拟合中最佳分裂点的发现。默认False，适用于大数据集。小数据集使用True,可以加快训练。是否预排序,预排序可以加速查找最佳分裂点，对于稀疏数据不管用，Bool，auto：非稀疏数据则预排序，若稀疏数据则不预排序。\n",
    "\n",
    "## 常用方法\n",
    "- predict_proba(x)：给出带有概率值的结果。每个点在所有label（类别）的概率和为1。\n",
    "- predict(x)：直接给出预测结果。内部还是调用的predict_proba()，根据概率的结果看哪个类型的预测值最高就是哪个类型。 \n",
    "- predict_log_proba(x)：和predict_proba基本上一样，只是把结果给做了log()处理。"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## 代码实践"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "import numpy as np\n",
    "import scipy\n",
    "import pandas as pd\n",
    "from sklearn.ensemble import RandomForestClassifier\n",
    "from sklearn.tree import DecisionTreeClassifier\n",
    "\n",
    "from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV\n",
    "from sklearn.metrics import roc_curve, auc, roc_auc_score\n",
    "\n",
    "import matplotlib.pyplot as plt"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "df=pd.read_csv('C:\\\\Users\\\\reina\\\\case-random forest.csv', encoding='gbk')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>业务1使用次数</th>\n",
       "      <th>渠道1时长</th>\n",
       "      <th>渠道1访问次数</th>\n",
       "      <th>渠道1消费</th>\n",
       "      <th>渠道2时长</th>\n",
       "      <th>渠道2访问次数</th>\n",
       "      <th>渠道2消费</th>\n",
       "      <th>渠道3时长</th>\n",
       "      <th>渠道3访问次数</th>\n",
       "      <th>渠道3消费</th>\n",
       "      <th>渠道4时长</th>\n",
       "      <th>渠道4访问次数</th>\n",
       "      <th>渠道4消费</th>\n",
       "      <th>与客服沟通次数</th>\n",
       "      <th>isrun</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>25</td>\n",
       "      <td>265.1</td>\n",
       "      <td>110</td>\n",
       "      <td>45.07</td>\n",
       "      <td>197.4</td>\n",
       "      <td>99</td>\n",
       "      <td>16.78</td>\n",
       "      <td>244.7</td>\n",
       "      <td>91</td>\n",
       "      <td>11.01</td>\n",
       "      <td>10.0</td>\n",
       "      <td>3</td>\n",
       "      <td>2.70</td>\n",
       "      <td>1</td>\n",
       "      <td>False.</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>26</td>\n",
       "      <td>161.6</td>\n",
       "      <td>123</td>\n",
       "      <td>27.47</td>\n",
       "      <td>195.5</td>\n",
       "      <td>103</td>\n",
       "      <td>16.62</td>\n",
       "      <td>254.4</td>\n",
       "      <td>103</td>\n",
       "      <td>11.45</td>\n",
       "      <td>13.7</td>\n",
       "      <td>3</td>\n",
       "      <td>3.70</td>\n",
       "      <td>1</td>\n",
       "      <td>False.</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>0</td>\n",
       "      <td>243.4</td>\n",
       "      <td>114</td>\n",
       "      <td>41.38</td>\n",
       "      <td>121.2</td>\n",
       "      <td>110</td>\n",
       "      <td>10.30</td>\n",
       "      <td>162.6</td>\n",
       "      <td>104</td>\n",
       "      <td>7.32</td>\n",
       "      <td>12.2</td>\n",
       "      <td>5</td>\n",
       "      <td>3.29</td>\n",
       "      <td>0</td>\n",
       "      <td>False.</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>0</td>\n",
       "      <td>299.4</td>\n",
       "      <td>71</td>\n",
       "      <td>50.90</td>\n",
       "      <td>61.9</td>\n",
       "      <td>88</td>\n",
       "      <td>5.26</td>\n",
       "      <td>196.9</td>\n",
       "      <td>89</td>\n",
       "      <td>8.86</td>\n",
       "      <td>6.6</td>\n",
       "      <td>7</td>\n",
       "      <td>1.78</td>\n",
       "      <td>2</td>\n",
       "      <td>False.</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>0</td>\n",
       "      <td>166.7</td>\n",
       "      <td>113</td>\n",
       "      <td>28.34</td>\n",
       "      <td>148.3</td>\n",
       "      <td>122</td>\n",
       "      <td>12.61</td>\n",
       "      <td>186.9</td>\n",
       "      <td>121</td>\n",
       "      <td>8.41</td>\n",
       "      <td>10.1</td>\n",
       "      <td>3</td>\n",
       "      <td>2.73</td>\n",
       "      <td>3</td>\n",
       "      <td>False.</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   业务1使用次数  渠道1时长  渠道1访问次数  渠道1消费  渠道2时长  渠道2访问次数  渠道2消费  渠道3时长  渠道3访问次数  \\\n",
       "0       25  265.1      110  45.07  197.4       99  16.78  244.7       91   \n",
       "1       26  161.6      123  27.47  195.5      103  16.62  254.4      103   \n",
       "2        0  243.4      114  41.38  121.2      110  10.30  162.6      104   \n",
       "3        0  299.4       71  50.90   61.9       88   5.26  196.9       89   \n",
       "4        0  166.7      113  28.34  148.3      122  12.61  186.9      121   \n",
       "\n",
       "   渠道3消费  渠道4时长  渠道4访问次数  渠道4消费  与客服沟通次数   isrun  \n",
       "0  11.01   10.0        3   2.70        1  False.  \n",
       "1  11.45   13.7        3   3.70        1  False.  \n",
       "2   7.32   12.2        5   3.29        0  False.  \n",
       "3   8.86    6.6        7   1.78        2  False.  \n",
       "4   8.41   10.1        3   2.73        3  False.  "
      ]
     },
     "execution_count": 3,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "2"
      ]
     },
     "execution_count": 4,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df.isrun.nunique()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "False.    2850\n",
       "True.      483\n",
       "Name: isrun, dtype: int64"
      ]
     },
     "execution_count": 5,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "df.isrun.value_counts()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "df.isrun=df.isrun.astype(str).map({'False.':0, 'True.':1})"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0    0\n",
       "1    0\n",
       "2    0\n",
       "3    0\n",
       "4    0\n",
       "Name: isrun, dtype: int64"
      ]
     },
     "execution_count": 7,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "y=df.isrun\n",
    "y.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<style scoped>\n",
       "    .dataframe tbody tr th:only-of-type {\n",
       "        vertical-align: middle;\n",
       "    }\n",
       "\n",
       "    .dataframe tbody tr th {\n",
       "        vertical-align: top;\n",
       "    }\n",
       "\n",
       "    .dataframe thead th {\n",
       "        text-align: right;\n",
       "    }\n",
       "</style>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>业务1使用次数</th>\n",
       "      <th>渠道1时长</th>\n",
       "      <th>渠道1访问次数</th>\n",
       "      <th>渠道1消费</th>\n",
       "      <th>渠道2时长</th>\n",
       "      <th>渠道2访问次数</th>\n",
       "      <th>渠道2消费</th>\n",
       "      <th>渠道3时长</th>\n",
       "      <th>渠道3访问次数</th>\n",
       "      <th>渠道3消费</th>\n",
       "      <th>渠道4时长</th>\n",
       "      <th>渠道4访问次数</th>\n",
       "      <th>渠道4消费</th>\n",
       "      <th>与客服沟通次数</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>25</td>\n",
       "      <td>265.1</td>\n",
       "      <td>110</td>\n",
       "      <td>45.07</td>\n",
       "      <td>197.4</td>\n",
       "      <td>99</td>\n",
       "      <td>16.78</td>\n",
       "      <td>244.7</td>\n",
       "      <td>91</td>\n",
       "      <td>11.01</td>\n",
       "      <td>10.0</td>\n",
       "      <td>3</td>\n",
       "      <td>2.70</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>26</td>\n",
       "      <td>161.6</td>\n",
       "      <td>123</td>\n",
       "      <td>27.47</td>\n",
       "      <td>195.5</td>\n",
       "      <td>103</td>\n",
       "      <td>16.62</td>\n",
       "      <td>254.4</td>\n",
       "      <td>103</td>\n",
       "      <td>11.45</td>\n",
       "      <td>13.7</td>\n",
       "      <td>3</td>\n",
       "      <td>3.70</td>\n",
       "      <td>1</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>0</td>\n",
       "      <td>243.4</td>\n",
       "      <td>114</td>\n",
       "      <td>41.38</td>\n",
       "      <td>121.2</td>\n",
       "      <td>110</td>\n",
       "      <td>10.30</td>\n",
       "      <td>162.6</td>\n",
       "      <td>104</td>\n",
       "      <td>7.32</td>\n",
       "      <td>12.2</td>\n",
       "      <td>5</td>\n",
       "      <td>3.29</td>\n",
       "      <td>0</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>0</td>\n",
       "      <td>299.4</td>\n",
       "      <td>71</td>\n",
       "      <td>50.90</td>\n",
       "      <td>61.9</td>\n",
       "      <td>88</td>\n",
       "      <td>5.26</td>\n",
       "      <td>196.9</td>\n",
       "      <td>89</td>\n",
       "      <td>8.86</td>\n",
       "      <td>6.6</td>\n",
       "      <td>7</td>\n",
       "      <td>1.78</td>\n",
       "      <td>2</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>0</td>\n",
       "      <td>166.7</td>\n",
       "      <td>113</td>\n",
       "      <td>28.34</td>\n",
       "      <td>148.3</td>\n",
       "      <td>122</td>\n",
       "      <td>12.61</td>\n",
       "      <td>186.9</td>\n",
       "      <td>121</td>\n",
       "      <td>8.41</td>\n",
       "      <td>10.1</td>\n",
       "      <td>3</td>\n",
       "      <td>2.73</td>\n",
       "      <td>3</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "   业务1使用次数  渠道1时长  渠道1访问次数  渠道1消费  渠道2时长  渠道2访问次数  渠道2消费  渠道3时长  渠道3访问次数  \\\n",
       "0       25  265.1      110  45.07  197.4       99  16.78  244.7       91   \n",
       "1       26  161.6      123  27.47  195.5      103  16.62  254.4      103   \n",
       "2        0  243.4      114  41.38  121.2      110  10.30  162.6      104   \n",
       "3        0  299.4       71  50.90   61.9       88   5.26  196.9       89   \n",
       "4        0  166.7      113  28.34  148.3      122  12.61  186.9      121   \n",
       "\n",
       "   渠道3消费  渠道4时长  渠道4访问次数  渠道4消费  与客服沟通次数  \n",
       "0  11.01   10.0        3   2.70        1  \n",
       "1  11.45   13.7        3   3.70        1  \n",
       "2   7.32   12.2        5   3.29        0  \n",
       "3   8.86    6.6        7   1.78        2  \n",
       "4   8.41   10.1        3   2.73        3  "
      ]
     },
     "execution_count": 8,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "x=df.drop('isrun', axis=1)   #dataframe.drop('isrun', axis=1)\n",
    "x.head()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "seed=5\n",
    "xtrain, xtest, ytrain, ytest = train_test_split(x, y, test_size=0.3, random_state=seed)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "collapsed": true
   },
   "source": [
    "### 模型的训练"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "metadata": {},
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "C:\\Users\\reina\\AppData\\Roaming\\Python\\Python36\\site-packages\\sklearn\\ensemble\\forest.py:245: FutureWarning: The default value of n_estimators will change from 10 in version 0.20 to 100 in 0.22.\n",
      "  \"10 in version 0.20 to 100 in 0.22.\", FutureWarning)\n"
     ]
    },
    {
     "data": {
      "text/plain": [
       "0.927"
      ]
     },
     "execution_count": 10,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfc = RandomForestClassifier()     #实例化 \n",
    "rfc = rfc.fit(xtrain,ytrain)       #用训练集数据训练模型 \n",
    "\n",
    "result = rfc.score(xtest,ytest)    #导入测试集，rfc的接口score计算的是模型准确率accuracy\n",
    "result"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 11,
   "metadata": {
    "scrolled": true
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "所有的树:[DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=1677838543, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=350549675, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=1005269485, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=343718680, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=763800750, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=1486604713, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=2037484788, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=526665927, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=280782529, splitter='best'), DecisionTreeClassifier(class_weight=None, criterion='gini', max_depth=None,\n",
      "                       max_features='auto', max_leaf_nodes=None,\n",
      "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
      "                       min_samples_leaf=1, min_samples_split=2,\n",
      "                       min_weight_fraction_leaf=0.0, presort=False,\n",
      "                       random_state=557246142, splitter='best')]\n"
     ]
    }
   ],
   "source": [
    "print ('所有的树:%s' % rfc.estimators_)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 12,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "[0 1]\n",
      "2\n"
     ]
    }
   ],
   "source": [
    "print (rfc.classes_)\n",
    "print (rfc.n_classes_)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 预测结果"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 13,
   "metadata": {
    "scrolled": true
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "判定结果：[0 0 0 0 0 1 1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 1 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 1 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 1 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 1 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 1 0 0 0 0 1 0 0 0 0 0 0 0 1 0 0\n",
      " 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 1 1 0 0 1 0 1 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0\n",
      " 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 1 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 1 0 0 0 0 1 0 0 0 1 0 0 0 0 0 0 1 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 1 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0\n",
      " 0 1 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 0 0 1 1 0 0 0 0 0 0 0 0 0 0 1 0 0\n",
      " 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0\n",
      " 0 0 0 0 0 1 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 1 0 0 0 0 0 0 0\n",
      " 0 0 1 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 1 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0\n",
      " 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0\n",
      " 0]\n"
     ]
    }
   ],
   "source": [
    "print ('判定结果：%s' % rfc.predict(xtest))\n",
    "#print rfc.predict_proba(feature_test[0])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 14,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "判定结果：[[0.9 0.1]\n",
      " [1.  0. ]\n",
      " [1.  0. ]\n",
      " ...\n",
      " [0.9 0.1]\n",
      " [0.8 0.2]\n",
      " [0.8 0.2]]\n"
     ]
    }
   ],
   "source": [
    "print ('判定结果：%s' % rfc.predict_proba(xtest)[:,:])   #标签是1的可能性"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 15,
   "metadata": {
    "scrolled": true
   },
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "判定结果：[0.1 0.  0.  0.1 0.1 0.8 0.9 0.4 0.  0.4 0.  0.  0.9 0.  0.5 0.  0.  0.\n",
      " 0.2 0.2 0.  0.  0.  0.  0.2 0.1 0.  0.3 0.  0.1 0.1 0.1 0.1 0.  0.  0.\n",
      " 0.  1.  0.  0.  0.  0.  0.1 0.  0.1 0.1 0.  0.  0.  0.1 0.3 0.2 0.  0.3\n",
      " 0.  0.  0.1 0.  0.3 0.  0.  0.  0.5 0.  0.1 0.3 0.1 0.6 0.9 0.6 0.  0.1\n",
      " 0.2 0.1 0.4 0.3 0.1 0.  0.  0.2 0.1 0.  0.  0.  0.  0.7 0.  0.  0.2 0.2\n",
      " 0.1 0.  0.  0.  0.1 0.7 0.7 0.  0.  0.3 0.4 0.1 0.  0.1 0.4 0.1 0.1 0.4\n",
      " 0.1 0.4 0.  0.4 0.2 0.  0.  0.2 0.  0.1 0.2 0.  0.1 0.  0.2 0.  0.  0.4\n",
      " 0.  0.9 0.  0.1 0.1 0.  0.7 0.1 0.2 0.5 0.3 0.3 0.1 0.1 0.1 0.2 0.  0.\n",
      " 0.5 0.2 0.4 0.  0.  0.1 0.3 0.3 0.  0.2 1.  0.  0.1 0.2 0.  0.1 0.1 0.1\n",
      " 0.9 0.3 0.1 0.3 0.6 0.2 0.1 0.3 0.1 0.9 0.  0.  0.4 0.  0.  0.  0.  0.1\n",
      " 0.1 0.1 0.  0.3 0.2 0.  0.  0.  0.  0.2 0.  0.1 0.  0.1 0.1 0.2 0.4 0.\n",
      " 0.1 0.  0.  0.  0.2 0.  0.1 0.  0.  0.2 0.  0.8 0.  0.1 0.2 0.2 0.4 0.1\n",
      " 0.3 0.1 0.2 0.  0.1 0.1 0.1 0.7 0.  0.  0.  0.4 0.7 0.  0.4 0.5 0.  0.1\n",
      " 0.  0.  0.3 0.  0.  0.  0.1 0.1 0.1 0.  0.2 0.1 0.  0.1 0.7 0.1 0.  0.\n",
      " 0.  0.3 0.  0.  0.9 0.9 0.  0.2 0.1 0.2 0.  0.5 0.  0.  0.  0.  0.  0.2\n",
      " 0.  0.1 0.7 0.1 0.2 0.2 0.  0.7 0.  0.  0.1 0.  0.1 0.  0.7 0.  0.1 0.\n",
      " 0.  0.7 0.  0.  0.2 0.2 0.  0.1 0.  0.  0.  0.1 0.1 0.  0.3 0.1 0.3 0.\n",
      " 0.  0.  0.4 0.1 0.1 0.4 0.  0.8 0.  0.  0.5 1.  0.  0.  0.  0.3 0.8 0.2\n",
      " 0.  0.  0.3 0.  0.5 0.2 0.6 0.  0.  0.2 0.1 0.  0.5 0.  0.5 0.  0.  0.6\n",
      " 0.  0.1 0.  0.1 0.1 0.  0.  0.1 0.  0.9 0.1 0.  0.  0.  0.  0.  0.  0.1\n",
      " 0.  0.4 0.2 0.7 0.  0.4 0.1 0.  0.1 0.  0.  0.  0.  0.1 0.  0.  0.  0.2\n",
      " 0.1 0.  0.  0.1 0.  0.2 0.  0.1 0.  0.  0.  0.5 0.2 0.  0.3 0.1 0.2 0.\n",
      " 0.  0.1 0.  0.1 0.  0.  0.  0.  0.  0.  0.5 0.2 0.1 0.  0.1 0.  0.  0.4\n",
      " 0.  0.4 0.  0.7 0.9 0.2 0.1 0.7 0.1 0.8 0.  0.5 0.  0.1 0.  0.  0.  0.6\n",
      " 0.1 0.  0.  0.  0.  0.  0.  0.6 0.2 0.4 0.  0.  0.  0.  0.  0.  0.1 0.1\n",
      " 0.  0.1 0.2 0.2 0.2 0.3 0.1 0.1 0.  0.  0.  0.  0.  0.3 0.2 0.  0.1 0.1\n",
      " 0.  0.2 0.  0.1 0.  0.4 0.3 0.  0.3 0.7 0.  0.  1.  0.2 0.1 0.4 0.1 0.4\n",
      " 0.  0.  0.  0.  0.1 0.3 0.  0.1 0.1 0.  0.1 0.5 0.5 0.  0.3 0.3 0.  0.\n",
      " 0.1 0.7 0.5 0.2 0.  0.  0.1 0.  0.2 0.1 0.2 0.  0.2 0.  0.5 0.4 0.  0.\n",
      " 0.2 0.  0.  0.1 0.  0.1 0.  0.1 0.  0.  0.  0.1 0.1 0.1 0.  0.2 0.  0.1\n",
      " 0.  0.1 0.1 0.  0.1 0.3 0.  0.  0.7 0.1 0.  0.2 0.1 0.  0.1 0.2 0.1 0.5\n",
      " 0.  0.1 1.  0.5 0.3 0.2 0.  0.3 0.7 0.3 0.2 0.3 0.7 0.  0.1 0.3 0.  0.1\n",
      " 0.  0.2 0.1 0.9 0.  0.  0.2 0.  0.  0.2 0.  0.  0.1 0.  0.4 0.  0.3 0.3\n",
      " 0.  0.  0.8 0.  0.  0.  0.  0.9 0.  0.1 0.1 0.9 0.  0.2 0.  0.  0.1 0.\n",
      " 0.9 0.  0.  0.6 0.1 0.  0.  0.2 0.  0.  0.2 0.2 0.1 0.1 0.2 0.4 0.  0.\n",
      " 0.3 0.  0.  0.2 0.  0.1 0.  0.8 0.  0.  0.4 0.1 0.  0.  0.  0.2 0.  0.\n",
      " 0.2 0.9 0.  0.  0.  0.4 0.  0.  0.2 0.  0.1 0.1 0.  0.1 0.  0.  0.1 0.2\n",
      " 0.7 0.  0.7 0.7 0.2 0.  0.4 0.1 0.  0.1 0.  0.  0.4 0.2 0.  0.  0.1 0.\n",
      " 0.  0.5 0.  0.6 0.4 0.  0.2 0.  0.  0.2 0.  0.  0.1 0.  0.3 0.  0.1 0.\n",
      " 0.  0.1 0.  0.1 0.  0.  0.  0.  0.1 0.  0.  0.  0.  0.7 0.2 0.1 0.1 0.\n",
      " 0.1 0.2 0.  0.1 0.5 0.2 0.2 0.2 0.4 0.  0.  0.  0.2 0.1 0.  0.2 0.8 0.1\n",
      " 0.1 0.1 0.  0.7 0.  0.  0.  0.  0.  0.1 0.3 0.2 0.  0.9 0.1 0.1 0.1 0.1\n",
      " 0.  0.1 0.  1.  0.2 0.5 0.9 1.  0.  0.1 0.5 0.5 0.1 0.1 0.  0.2 0.2 0.\n",
      " 0.7 0.1 0.  0.  0.1 0.3 0.4 0.1 0.  0.7 0.6 0.1 0.  0.  0.1 0.3 0.  0.1\n",
      " 0.  0.  0.  0.2 0.5 0.3 0.1 0.1 0.1 0.  0.  0.1 0.7 0.  0.1 0.3 0.1 0.\n",
      " 0.  0.  0.  0.3 0.  0.  0.1 0.  0.  0.3 0.  0.  0.5 0.2 0.  0.1 0.1 0.\n",
      " 0.1 0.1 0.2 0.1 0.9 0.1 0.3 0.1 0.1 0.1 0.2 0.1 0.  0.1 0.  0.1 0.  0.1\n",
      " 0.  0.  0.8 0.  0.  0.1 0.  0.  0.  0.  1.  0.6 0.2 0.2 0.5 0.  0.5 0.1\n",
      " 0.6 0.3 0.  0.1 0.  0.  0.  0.  0.  0.1 0.5 0.3 0.2 0.  0.1 0.9 0.6 0.\n",
      " 0.  0.  0.  0.1 0.1 0.2 0.1 0.1 1.  0.3 0.4 0.  1.  0.1 0.  0.2 0.  0.\n",
      " 0.1 0.  0.2 0.1 0.2 0.  0.1 0.2 0.  0.  0.2 0.4 0.1 0.9 0.  0.  0.6 0.\n",
      " 0.2 0.1 0.  0.1 0.5 0.  0.  0.1 0.  0.1 0.4 0.5 0.  0.1 0.2 0.1 0.  0.7\n",
      " 0.  0.1 0.1 0.  0.  0.2 0.1 0.  0.7 0.  0.1 0.1 0.  0.  0.2 0.  0.  0.1\n",
      " 0.  0.  0.  0.3 0.  0.1 0.  0.1 0.  0.1 0.  0.  0.  0.  0.9 0.3 0.1 0.2\n",
      " 0.3 0.1 0.1 0.  0.2 0.  0.  0.1 0.9 0.  0.  0.  0.  0.1 0.  0.  0.3 0.1\n",
      " 0.1 0.9 0.  0.1 0.  0.1 0.2 0.1 0.2 0.2]\n"
     ]
    }
   ],
   "source": [
    "print ('判定结果：%s' % rfc.predict_proba(xtest)[:,1])   #标签是1的可能性"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 16,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "True"
      ]
     },
     "execution_count": 16,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "#对比一下，（1）使用predict_proba()接口，然后将标签值为1的概率>0.5的样本即判断其属于标签值为1的那一类；\n",
    "#（2）直接使用predict接口，判断其属于哪一类\n",
    "d1=np.array(pd.Series(rfc.predict_proba(xtest)[:,1]>0.5).map({False:0, True:1}))\n",
    "d2=rfc.predict(xtest)\n",
    "np.array_equal(d1,d2)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 17,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.8955312159586056"
      ]
     },
     "execution_count": 17,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "roc_auc_score(ytest, rfc.predict_proba(xtest)[:,1])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 特征的重要性与可视化"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "各feature的重要性：[0.03712965 0.18343016 0.04334802 0.13267122 0.07187646 0.03980911\n",
      " 0.07760184 0.05989182 0.04591539 0.06025719 0.05047851 0.03731322\n",
      " 0.04095658 0.11932083]\n"
     ]
    }
   ],
   "source": [
    "print ('各feature的重要性：%s' % rfc.feature_importances_)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 19,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Feature ranking:\n",
      " 1) 渠道1时长                          0.183430\n",
      " 2) 渠道1消费                          0.132671\n",
      " 3) 与客服沟通次数                        0.119321\n",
      " 4) 渠道2消费                          0.077602\n",
      " 5) 渠道2时长                          0.071876\n",
      " 6) 渠道3消费                          0.060257\n",
      " 7) 渠道3时长                          0.059892\n",
      " 8) 渠道4时长                          0.050479\n",
      " 9) 渠道3访问次数                        0.045915\n",
      "10) 渠道1访问次数                        0.043348\n",
      "11) 渠道4消费                          0.040957\n",
      "12) 渠道2访问次数                        0.039809\n",
      "13) 渠道4访问次数                        0.037313\n",
      "14) 业务1使用次数                        0.037130\n"
     ]
    },
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAX4AAAEICAYAAABYoZ8gAAAABHNCSVQICAgIfAhkiAAAAAlwSFlz\nAAALEgAACxIB0t1+/AAAFtZJREFUeJzt3XvUXXV95/H3xwBeIopCRCDh0pahMlbUpshMqT5otQQv\nsc64But9tAyzyrLMjKNUZ1x2WtfSjtM14xo0RaVaFbFVUWqjgNOmzhSxBAsYbhoCNgmXBAVFsULg\nO3/sHT08PiEnOfu58Xu/1jrrOfv23d+znyefs89vn3OSqkKS1I5HzHcDkqS5ZfBLUmMMfklqjMEv\nSY0x+CWpMQa/JDXG4FfTkqxJ8l/nuw9pLsX38WtvJLkZOBi4f2T2P6uqWyaoOQV8vKqWT9bd4pTk\nI8CWqvov892LHt4849ckXlxVjx257XXoDyHJPvO5/0kkWTLfPagdBr8Gl+SEJJcmuSvJVf2Z/M5l\nr09yXZK7k2xK8u/6+UuBLwKHJvlBfzs0yUeS/OHI9lNJtoxM35zkrUmuBn6YZJ9+u88k2Z7kpiRv\neohef1J/Z+0kb0myLcmtSV6a5JQk30zy3SRvG9n2nUk+neRT/eP5epLjRpY/Jcm6/jhck+Ql0/b7\ngSRrk/wQeAPwSuAt/WP/y369s5Lc2Ne/NslvjtR4XZL/l+S9Se7sH+uqkeVPTPKnSW7pl39uZNmL\nklzZ93ZpkqeNLHtrkq39Pm9I8rwxfu1aTKrKm7c9vgE3A78+w/zDgO8Ap9CdWDy/n17WL38h8PNA\ngOcA9wDP7JdN0Q11jNb7CPCHI9MPWqfv40pgBfDofp9XAO8A9gN+DtgE/MYuHsdP6ve1d/Tb7gv8\nNrAdOA/YH/jnwI+Ao/r13wncB/zrfv03Azf19/cFNgJv6/t4LnA3cMzIfr8H/Grf86OmP9Z+vZcD\nh/br/Bvgh8Ah/bLX9fv/bWAJ8O+BW/jpEO5fAZ8CntD385x+/jOAbcCz+u1e2x/HRwLHAJuBQ/t1\njwR+fr7/3rwNe/OMX5P4XH/GeNfI2eSrgLVVtbaqHqiqS4D1dE8EVNVfVdWN1flb4GLg1ybs431V\ntbmqfgT8Ct2TzH+rqnurahPwQeDUMWvdB7yrqu4DzgcOAv5XVd1dVdcA1wLHjax/RVV9ul//j+kC\n/IT+9ljg3X0ffw18AXjFyLafr6q/64/TP83UTFX9RVXd0q/zKeBbwPEjq3y7qj5YVfcDHwUOAQ5O\ncgiwCji9qu6sqvv64w1wGvAnVfW1qrq/qj4K/Ljv+X66J4Bjk+xbVTdX1Y1jHjstEga/JvHSqjqg\nv720n3cE8PKRJ4S7gBPpAokkq5Jc1g+b3EX3hHDQhH1sHrl/BN1w0ej+30Z3IXoc3+lDFLqze4Db\nR5b/iC7Qf2bfVfUAsIXuDP1QYHM/b6dv070imqnvGSV5zciQzF3AU3nw8bptZP/39HcfS/cK6LtV\ndecMZY8A/tO0Y7SC7ix/I3Am3auZbUnOT3Lo7vrU4mLwa2ibgY+NPCEcUFVLq+rdSR4JfAZ4L3Bw\nVR0ArKUb9gGY6S1mPwQeMzL95BnWGd1uM3DTtP3vX1WnTPzIZrZi550kjwCW0w233AKs6OftdDiw\ndRd9/8x0kiPoXq2cARzYH68N/PR4PZTNwBOTHLCLZe+adoweU1WfBKiq86rqRLoniALeM8b+tIgY\n/Brax4EXJ/mNJEuSPKq/aLqcbqz7kXTj5jv6C5EvGNn2duDAJI8fmXclcEp/ofLJdGejD+Xvgbv7\nC5SP7nt4apJfGewRPtgvJ3lZuncUnUk3ZHIZ8DW66xdvSbJvf4H7xXTDR7tyO901iZ2W0gXvdugu\njNOd8e9WVd1Kd7H8/Ume0Pfw7H7xB4HTkzwrnaVJXphk/yTHJHlu/yT9T3SvcB7YxW60SBn8GlRV\nbQZW0w2vbKc7u/zPwCOq6m7gTcCfA3cCvwVcOLLt9cAngU39EMShwMeAq+guPl5Md7HyofZ/P/Ai\n4Ol0F1rvAD4EPP6htpvA5+kuut4JvBp4WT+efi9d0K/qe3g/8Jr+Me7Kh+nG1u9K8rmquhb4H8BX\n6Z4Ufgn4uz3o7dV01yyup7uYeyZAVa2nuyD8v/u+N9JdKIbuifndfc+3AU8Cfm8P9qlFwA9wSXsp\nyTuBX6iqV813L9Ke8Ixfkhpj8EtSYxzqkaTGeMYvSY1ZkF9qddBBB9WRRx45321I0qJxxRVX3FFV\ny8ZZd0EG/5FHHsn69evnuw1JWjSSfHvcdR3qkaTGGPyS1BiDX5IaY/BLUmMMfklqjMEvSY0x+CWp\nMQa/JDXG4JekxjQT/FNTU0xNTc13G5I075oJfklSx+CXpMYY/JLUGINfkhpj8EtSYwx+SWqMwS9J\njTH4JakxBr8kNcbgl6TGGPyS1Jixgj/JyUluSLIxyVkzLH9lkquTfCPJpUmOG1l2cz//yiTrh2xe\nkrTn9tndCkmWAGcDzwe2AJcnubCqrh1Z7SbgOVV1Z5JVwDnAs0aWn1RVdwzYtyRpL41zxn88sLGq\nNlXVvcD5wOrRFarq0qq6s5+8DFg+bJuSpKGME/yHAZtHprf083blDcAXR6YL+HKSK5KctquNkpyW\nZH2S9du3bx+jLUnS3tjtUM+eSHISXfCfODL7xKramuRJwCVJrq+qr0zftqrOoRsiYuXKlTVkX5Kk\nnxrnjH8rsGJkenk/70GSPA34ELC6qr6zc35Vbe1/bgMuoBs6kiTNk3GC/3Lg6CRHJdkPOBW4cHSF\nJIcDnwVeXVXfHJm/NMn+O+8DLwA2DNW8JGnP7Xaop6p2JDkDuAhYApxbVdckOb1fvgZ4B3Ag8P4k\nADuqaiVwMHBBP28f4Lyq+tKsPBJJ0ljGGuOvqrXA2mnz1ozcfyPwxhm22wQcN32+JGn++MldSWqM\nwS9JjTH4JakxBr8kNcbgl6TGGPyS1BiDX5IaY/BLUmMMfklqjMEvSY0x+CWpMQa/JDXG4Jekxhj8\nktQYg1+SGmPwS1JjDH5JaozBL0mNMfglqTEGvyQ1xuCXpMYY/JLUGINfkhpj8EtSYwx+SWqMwS9J\njTH4JakxBr8kNcbgl6TGjBX8SU5OckOSjUnOmmH5K5NcneQbSS5Ncty420qS5tZugz/JEuBsYBVw\nLPCKJMdOW+0m4DlV9UvAHwDn7MG2kqQ5NM4Z//HAxqraVFX3AucDq0dXqKpLq+rOfvIyYPm420qS\n5tY4wX8YsHlkeks/b1feAHxxT7dNclqS9UnWb9++fYy2FoapqSmmpqbmuw1JGtugF3eTnEQX/G/d\n022r6pyqWllVK5ctWzZkW5KkEfuMsc5WYMXI9PJ+3oMkeRrwIWBVVX1nT7aVJM2dcc74LweOTnJU\nkv2AU4ELR1dIcjjwWeDVVfXNPdlWkjS3dnvGX1U7kpwBXAQsAc6tqmuSnN4vXwO8AzgQeH8SgB39\nsM2M287SY5EkjWGcoR6qai2wdtq8NSP33wi8cdxtJUnzx0/uSlJjDH5JaozBL0mNMfglqTEGvyQ1\nxuCXpMYY/JLUmLHex78odB8cm3y9qsl7kaQFzDN+SWqMwS9JjTH4JakxBr8kNcbgl6TGGPyS1BiD\nX5IaY/BLUmMMfklqjMEvSY0x+CWpMQa/JDXG4Jekxhj8ktQYg1+SGmPwS1JjDH5JaozBL0mNMfgl\nqTEGvyQ1xuCXpMaMFfxJTk5yQ5KNSc6aYfkvJvlqkh8nefO0ZTcn+UaSK5OsH6pxSdLe2Wd3KyRZ\nApwNPB/YAlye5MKqunZkte8CbwJeuosyJ1XVHZM2K0ma3Dhn/McDG6tqU1XdC5wPrB5doaq2VdXl\nwH2z0KMkaUDjBP9hwOaR6S39vHEV8OUkVyQ5bU+akyQNb7dDPQM4saq2JnkScEmS66vqK9NX6p8U\nTgM4/PDD56AtSWrTOGf8W4EVI9PL+3ljqaqt/c9twAV0Q0czrXdOVa2sqpXLli0bt7wkaQ+NE/yX\nA0cnOSrJfsCpwIXjFE+yNMn+O+8DLwA27G2zkqTJ7Xaop6p2JDkDuAhYApxbVdckOb1fvibJk4H1\nwOOAB5KcCRwLHARckGTnvs6rqi/NzkORJI1jrDH+qloLrJ02b83I/dvohoCm+z5w3CQNSpKG5Sd3\nF7CpqSmmpqbmuw1JDzMGvyQ1xuCXpMYY/JLUGINfkhpj8EtSYwx+SWqMwS9JjZmLL2lb3LpPHU++\nXtXkvUjSADzjl6TGGPyS1BiDX5IaY/BLUmMMfklqjMEvSY0x+CWpMQa/JDXG4JekxvjJ3fk0xKeC\n/USwpD3kGb8kNcbgl6TGGPyS1BiDX5IaY/BLUmMMfklqjMEvSY0x+CWpMQa/JDXG4G/Q1NQUU1NT\n892GpHli8EtSY8YK/iQnJ7khycYkZ82w/BeTfDXJj5O8eU+2lSTNrd0Gf5IlwNnAKuBY4BVJjp22\n2neBNwHv3YttJUlzaJwz/uOBjVW1qaruBc4HVo+uUFXbqupy4L493VaSNLfGCf7DgM0j01v6eeMY\ne9skpyVZn2T99u3bxywvSdpTC+biblWdU1Urq2rlsmXL5rsdSXrYGuc/YtkKrBiZXt7PG8ck2w5q\n3XzsVJIWoHGC/3Lg6CRH0YX2qcBvjVl/km2bt26+G5D0sLTb4K+qHUnOAC4ClgDnVtU1SU7vl69J\n8mRgPfA44IEkZwLHVtX3Z9p2th6MJGn3xvo/d6tqLbB22rw1I/dvoxvGGWtbPTzt/DTwunXr5rUP\nSQ9twVzclSTNDYNfkhpj8EtSYwx+Nc1vKlWLDH5JaozBL0mNMfglqTEGvyQ1xuCXpMYY/JLUGINf\nkhoz1nf1aJFJhlmvavJeJC04nvFLUmMMfklqjMEvSY0x+CWpMV7c1fjm6aKx/8GLNCzP+CWpMQa/\nJDXG4Jekxhj8ktQYL+5OaN18N6AFyQvSWsg845ekxhj8ktQYh3q0MIzzGQG/VG5WOTzVDoNfD29+\nU6n0MxzqkaTGGPzSIjI1NfWTIRlpbxn8ktSYsYI/yclJbkiyMclZMyxPkvf1y69O8syRZTcn+UaS\nK5OsH7J5SQufr1IWnt1e3E2yBDgbeD6wBbg8yYVVde3IaquAo/vbs4AP9D93Oqmq7hisa0nSXhvn\njP94YGNVbaqqe4HzgdXT1lkN/Fl1LgMOSHLIwL1KkgYwzts5DwM2j0xv4cFn87ta5zDgVqCALye5\nH/iTqjpnpp0kOQ04DeDwww8fq3lp3vg20Xnn5w723ly8j//Eqtqa5EnAJUmur6qvTF+pf0I4B2Dl\nypX+a1iE1i2yutJcWyhPVuMM9WwFVoxML+/njbVOVe38uQ24gG7oSPNoHYap1LJxgv9y4OgkRyXZ\nDzgVuHDaOhcCr+nf3XMC8L2qujXJ0iT7AyRZCrwA2DBg/5I0uIf7O5F2O9RTVTuSnAFcBCwBzq2q\na5Kc3i9fA6wFTgE2AvcAr+83Pxi4IN045z7AeVX1pcEfhfRw4vcWaZaNNcZfVWvpwn103pqR+wX8\nzgzbbQKOm7BHSUPwgrR6fnJXkhrjt3NKmoyvJBYdg1/SwuQTyqxxqEeSGuMZv6T2zNariUXyKsXg\nl2bBuvluQHoIDvVIUmM845cWkXXz3YAeFgx+NW3dfDcgzQOHeiSpMZ7xS1qU1s13A4uYwS9J06yb\n7wZmmcEvaVatm+8G9DMMfkmAAT0X1s13Az0v7kpSYwx+SWqMwS9JjTH4JakxBr8kNcbgl6TGGPyS\n1BiDX5IaY/BLUmMMfklqjMEvSY0x+CWpMQa/JDXG4Jekxhj8ktQYg1+SGjNW8Cc5OckNSTYmOWuG\n5Unyvn751UmeOe62kqS5tdvgT7IEOBtYBRwLvCLJsdNWWwUc3d9OAz6wB9tKkubQOGf8xwMbq2pT\nVd0LnA+snrbOauDPqnMZcECSQ8bcVpI0h8b5P3cPAzaPTG8BnjXGOoeNuS0ASU6je7UA8IMkN4zR\n2546CLjjIddIFlLd3deerbp7X3ux1Z3N2out7mzWXmx1Z7P2bNU9YtwVF8x/tl5V5wDnzOY+kqyv\nqpWLpe5s1rbu7NdebHVns/ZiqzubtWez53GNE/xbgRUj08v7eeOss+8Y20qS5tA4Y/yXA0cnOSrJ\nfsCpwIXT1rkQeE3/7p4TgO9V1a1jbitJmkO7PeOvqh1JzgAuApYA51bVNUlO75evAdYCpwAbgXuA\n1z/UtrPySMYzW0NJszlEtdh6Xmx1Z7P2Yqs7m7UXW93ZrD2rQ9rjSFXNdw+SpDnkJ3clqTEGvyQ1\npongT3Jukm1JNgxc91FJ/j7JVUmuSfL7Q/aY5A/6r8C4MsnFSQ4doOcDknw6yfVJrkvyLyatOVJ7\nSZJ/SPKFoWr2dX83yYb+GJ85UM1j+uO68/b9SWrv4vf3xCSXJPlW//MJA/T9H/rjsCHJJ5M8aoCa\nK5L8TZJr+9q/O2G9mY7Ff+//5q5OckGSAwbo++Yk3+h/f+sH7vfl/bF4IMkgb71cUF9fU1UP+xvw\nbOCZwIaB6wZ4bH9/X+BrwAlD9Qg8buT+m4A1A/T8UeCN/f39gAMGPB7/ETgP+MKANZ8KbAAeQ/dm\nhC8DvzDw73EJcBtwxJB/Y8AfAWf1988C3jNhn4cBNwGP7qf/HHjdAI//EOCZ/f39gW8Cxw58LF4A\n7NPff8+kx6KvczNw0AB1Zur3KcAxwDpg5UB/YzcCP9f/u7tqkmM86a2JM/6q+grw3VmoW1X1g35y\n3/62V1fLZ+qxqr4/Mrl0b2vvlOTxdH/kH+7r31tVd01Sc6T2cuCFwIeGqDfiKcDXquqeqtoB/C3w\nsoH38Tzgxqr69t4W2MXf2Gq6J1r6ny/d2/oj9gEenWQfuifDWyYtWFW3VtXX+/t3A9fRPcnsbb2Z\n/pYv7n9/AJfRfaZnQdhFv9dV1ZDfHrCgvr6mieCfTf3wxpXANuCSqvrawPXflWQz8ErgHROWOwrY\nDvxpPyTzoSRLJ26y8z+BtwAPDFRvpw3AryU5MMlj6N42vGI32+ypU4FPDlwT4ODqPs8C3SuKgycp\nVlVbgfcC/wjcSvd5mYsna/HBkhwJPIPu1ets+bfAFweoU8CXk1zRf+XLQrarr7WZFwb/hKrq/qp6\nOt0ZzPFJnjpw/bdX1QrgE8AZE5bbh+4l7Qeq6hnAD+mGICaS5EXAtqq6YtJa01XVdXRDAxcDXwKu\nBO4fqn7/wcKXAH8xVM2ZVPd6f9JXbE+gO0s8CjgUWJrkVQO0t7P+Y4HPAGdOe7U5mCRvB3bQ/T1P\n6sT+394q4HeSPHuAmk0w+AfSD5n8DXDyLO3iE8C/mrDGFmDLyKuST9M9EUzqV4GXJLmZ7iXsc5N8\nfIC6AFTVh6vql6vq2cCddGPQQ1kFfL2qbh+w5k63p/uWWvqf2yas9+vATVW1varuAz4L/MsJawKQ\nZF+60P9EVX12iJoz7ON1wIuAV/ZPhBPpXwFRVduAC+iGUxaqcb76Zs4Y/BNIsmznuxOSPBp4PnD9\ngPWPHplcPWntqroN2JzkmH7W84BrJ6nZ1/29qlpeVUfSDZv8dVUNeSb6pP7n4XTj++cNVRt4BbMz\nzAPd15O8tr//WuDzE9b7R+CEJI9JErrf33UT1qSv9WHguqr640nr7WIfJ9MNBb6kqu4ZoN7SJPvv\nvE938XjQd+0NbGF9fc18XVWeyxvdP+xbgfvoznrfMFDdpwH/AFxN90f3jiF7pDsD29DX/0vgsAF6\nfjqwvq/5OeAJAx/rKQZ8V09f8//SPUFdBTxvwLpLge8Aj5+NvzHgQOD/AN+iezfSEwfYz+/TnQBs\nAD4GPHKAmifSDUNdTTeUdiVwysDHYiPdGPfO+hO9Q43u3TFX9bdrgLcP3O9v9vd/DNwOXDTAcT6F\n7tXqjZP0O8TNr2yQpMY41CNJjTH4JakxBr8kNcbgl6TGGPyS1BiDX5IaY/BLUmP+P1pDvrxJjdd2\nAAAAAElFTkSuQmCC\n",
      "text/plain": [
       "<matplotlib.figure.Figure at 0x164bdffbe48>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "importances = rfc.feature_importances_\n",
    "std = np.std([tree.feature_importances_ for tree in rfc.estimators_], axis=0)\n",
    "indices = np.argsort(importances)[::-1]# Print the feature ranking\n",
    "print(\"Feature ranking:\")\n",
    "for f in range(min(20,xtrain.shape[1])):    \n",
    "    print(\"%2d) %-*s %f\" % (f + 1, 30, xtrain.columns[indices[f]], importances[indices[f]]))# Plot the feature importances of the forest\n",
    "plt.figure()\n",
    "plt.title(\"Feature importances\")\n",
    "plt.bar(range(xtrain.shape[1]), importances[indices],  color=\"r\", yerr=std[indices], align=\"center\")\n",
    "plt.xticks(range(xtrain.shape[1]), indices)\n",
    "plt.xlim([-1, xtrain.shape[1]])\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 20,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "('渠道1时长',\n",
       " '渠道1消费',\n",
       " '与客服沟通次数',\n",
       " '渠道2消费',\n",
       " '渠道2时长',\n",
       " '渠道3消费',\n",
       " '渠道3时长',\n",
       " '渠道4时长',\n",
       " '渠道3访问次数',\n",
       " '渠道1访问次数',\n",
       " '渠道4消费',\n",
       " '渠道2访问次数',\n",
       " '渠道4访问次数',\n",
       " '业务1使用次数')"
      ]
     },
     "execution_count": 20,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "tuple(xtrain.columns[indices])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 21,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAbwAAAE/CAYAAAA9lHapAAAABHNCSVQICAgIfAhkiAAAAAlwSFlz\nAAALEgAACxIB0t1+/AAAGrpJREFUeJzt3X+wX3V95/Hnq0GqIgqUyI8kGOxmZFmnRicirW63XYrL\nD2twp7WwLaK1RXZEZFd3Td2ZrtP90ayLP+rIkEHNitVKEUWzSyoi7bTr+mMTKPLTrDGGJjEkEVQo\nWCHmvX98T/Rwc2/uuckll3s/z8fMd77nfM7n8zmfz/cm93XP+Z7v+aaqkCRprvuZmR6AJEmHgoEn\nSWqCgSdJaoKBJ0lqgoEnSWqCgSdJaoKBJ0lqgoGnWS/J5iQ/TPL3vceJB9nnryTZOl1jHLjPjyb5\nz4dynxNJ8q4kH5/pcUjTycDTXPHrVfWs3uM7MzmYJIfN5P4Pxmweu7Q/Bp7mtCSnJ/lyku8n+XqS\nX+lte0OSe5M8nGRTkjd15UcAfwGc2D9iHHsENvYosDvSfEeSO4BHkhzWtft0kl1Jvp3ksoHjXpyk\nujFuSfK9JJckeWmSO7r5fLBX//VJ/k+SDyb5QZJvJDmjt/3EJGuSPJhkY5Lf7217V5Lrk3w8yUPA\nJcA7gd/q5v71/b1e/dciyduS7EyyPckbetufkeQ9Se7rxvelJM8Y8DN6fbevh7vX77eHvH7SePxL\nTnNWkgXAjcCFwOeBM4BPJzmlqnYBO4FXAZuAXwb+Ism6qrotydnAx6tqYa+/Ibu9ADgX+C6wB/if\nwOe68oXAF5NsqKqbBk7jZcCSbnxrunn8GvA04G+TfKqq/rpX93rgWOBfAp9JcnJVPQhcC9wFnAic\nAtyc5FtV9Zdd2+XAbwKvA3626+MfVdXv9MYy4evVbT8eeA6wADgTuD7JZ6vqe8AVwD8Bfgm4vxvr\nnv39jIBHgQ8AL62qDUlOAI4Z+LpJ+/AIT3PFZ7sjhO8n+WxX9jvA2qpaW1V7qupmYD1wDkBV3VhV\n36qRvwa+APzTgxzHB6pqS1X9EHgpML+q/qiqHquqTcCHgPOn0N9/qqp/qKovAI8An6yqnVW1Dfjf\nwIt7dXcC76+qx6vqz4ENwLlJFgEvB97R9XU78GFG4bbXV6rqs93r9MPxBjLg9Xoc+KNu/2uBvwde\nkORngN8F3lpV26rqx1X15ar6EZP8jBj90fDCJM+oqu1VdfcUXjvpCQw8zRXnVdVR3eO8rux5wG/2\ngvD7wCuAEwCSnJ3kq91pvu8z+iV77EGOY0tv+XmMTov29/9O4Lgp9Lejt/zDcdaf1VvfVk+8G/x9\njI7oTgQerKqHx2xbMMG4xzXg9Xqgqnb31h/txncs8HTgW+N0O+HPqKoeAX6L0SnW7Ulu7I78pANi\n4Gku2wL8aS8Ij6qqI6pqZZKfBT7N6FTbcVV1FLAW2HvecryvEXkEeGZv/fhx6vTbbQG+PWb/R1bV\nOeO0mw4L8sTzricB3+kexyQ5csy2bROMe5/1Aa/X/nwX+Afg58fZNuHPCKCqbqqqMxn9kfINRkfI\n0gEx8DSXfRz49ST/Ism8JE/vLq5YCBzO6L2qXcDu7j27V/ba7gB+LslzemW3A+ckOSbJ8cDlk+z/\n/wIPdxeyPKMbwwuTvHTaZvhEzwUuS/K0JL8J/GNGpwu3AF8G/rh7DX4BeCOj12ciO4DF3elImPz1\nmlBV7QFWA+/tLp6Zl+QXuxCd8GeU5LgkyzO6iOhHjE6R7pniayL9hIGnOav7Rb+c0WnEXYyOJv4d\n8DPd6b3LgOuA7wH/itFFIXvbfgP4JLCpO9V2IvCnwNeBzYzev/rzSfb/Y0YXeSwFvs3oSOfDjC7s\neDJ8jdEFLt8F/gvwG1X1QLftAmAxo6O9G4D/WFVf3E9fn+qeH0hy22Sv1wBvB+4E1gEPAv+N0c9h\nwp9R9/i33ZgfBP4Z8K+nsE/pCeIXwEqzX5LXA79XVa+Y6bFIT1Ue4UmSmmDgSZKa4ClNSVITPMKT\nJDXBwJMkNWFW3Uvz2GOPrcWLF8/0MCRJTyG33nrrd6tq/mT1ZlXgLV68mPXr18/0MCRJTyFJ7htS\nz1OakqQmGHiSpCYYeJKkJhh4kqQmGHiSpCYYeJKkJhh4kqQmGHiSpCYYeJKkJhh4kqQmGHiSpCbM\nqntpziaLV9w47X1uXnnutPcpSa3wCE+S1AQDT5LUBANPktQEA0+S1AQDT5LUBANPktQEA0+S1IRB\ngZfkrCQbkmxMsmKc7ack+UqSHyV5e6/8BUlu7z0eSnJ5t+1dSbb1tp0zfdOSJOmJJv3geZJ5wJXA\nmcBWYF2SNVV1T6/ag8BlwHn9tlW1AVja62cbcEOvyvuq6oqDmoEkSQMMOcI7DdhYVZuq6jHgWmB5\nv0JV7ayqdcDj++nnDOBbVXXfAY9WkqQDNCTwFgBbeutbu7KpOh/45JiytyS5I8nqJEcfQJ+SJA1y\nSC5aSXI48GrgU73iq4DnMzrluR14zwRtL06yPsn6Xbt2PeljlSTNTUMCbxuwqLe+sCubirOB26pq\nx96CqtpRVT+uqj3AhxidOt1HVV1dVcuqatn8+fOnuFtJkkaGBN46YEmSk7sjtfOBNVPczwWMOZ2Z\n5ITe6muAu6bYpyRJg016lWZV7U5yKXATMA9YXVV3J7mk274qyfHAeuDZwJ7uowenVtVDSY5gdIXn\nm8Z0/e4kS4ECNo+zXZKkaTPo+/Cqai2wdkzZqt7y/YxOdY7X9hHg58Ypv3BKI5Uk6SB4pxVJUhMM\nPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJ\nUhMMPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJUhMMPElSEww8SVIT\nDDxJUhMMPElSEwYFXpKzkmxIsjHJinG2n5LkK0l+lOTtY7ZtTnJnktuTrO+VH5Pk5iTf7J6PPvjp\nSJI0vkkDL8k84ErgbOBU4IIkp46p9iBwGXDFBN38alUtraplvbIVwC1VtQS4pVuXJOlJMeQI7zRg\nY1VtqqrHgGuB5f0KVbWzqtYBj09h38uBa7rla4DzptBWkqQpGRJ4C4AtvfWtXdlQBXwxya1JLu6V\nH1dV27vl+4HjptCnJElTctgh2McrqmpbkucCNyf5RlX9Tb9CVVWSGq9xF5IXA5x00klP/mglSXPS\nkCO8bcCi3vrCrmyQqtrWPe8EbmB0ihRgR5ITALrnnRO0v7qqllXVsvnz5w/drSRJTzAk8NYBS5Kc\nnORw4HxgzZDOkxyR5Mi9y8Argbu6zWuAi7rli4DPTWXgkiRNxaSnNKtqd5JLgZuAecDqqro7ySXd\n9lVJjgfWA88G9iS5nNEVnccCNyTZu68/q6rPd12vBK5L8kbgPuC10zs1SZJ+atB7eFW1Flg7pmxV\nb/l+Rqc6x3oIeNEEfT4AnDF4pJIkHQTvtCJJaoKBJ0lqgoEnSWqCgSdJaoKBJ0lqgoEnSWqCgSdJ\naoKBJ0lqgoEnSWqCgSdJaoKBJ0lqgoEnSWqCgSdJaoKBJ0lqgoEnSWqCgSdJaoKBJ0lqgoEnSWqC\ngSdJaoKBJ0lqwmEzPQDNDotX3Dit/W1eee609idJk/EIT5LUBANPktQEA0+S1AQDT5LUBANPktQE\nA0+S1IRBgZfkrCQbkmxMsmKc7ack+UqSHyV5e698UZK/SnJPkruTvLW37V1JtiW5vXucMz1TkiRp\nX5N+Di/JPOBK4ExgK7AuyZqquqdX7UHgMuC8Mc13A2+rqtuSHAncmuTmXtv3VdUVBz0LSZImMeQI\n7zRgY1VtqqrHgGuB5f0KVbWzqtYBj48p315Vt3XLDwP3AgumZeSSJE3BkMBbAGzprW/lAEIryWLg\nxcDXesVvSXJHktVJjp6g3cVJ1idZv2vXrqnuVpIk4BBdtJLkWcCngcur6qGu+Crg+cBSYDvwnvHa\nVtXVVbWsqpbNnz//UAxXkjQHDQm8bcCi3vrCrmyQJE9jFHafqKrP7C2vqh1V9eOq2gN8iNGpU0mS\nnhRDAm8dsCTJyUkOB84H1gzpPEmAjwD3VtV7x2w7obf6GuCuYUOWJGnqJr1Ks6p2J7kUuAmYB6yu\nqruTXNJtX5XkeGA98GxgT5LLgVOBXwAuBO5McnvX5Turai3w7iRLgQI2A2+a3qlJkvRTg74eqAuo\ntWPKVvWW72d0qnOsLwGZoM8Lhw9TkqSD451WJElNMPAkSU3wG88lSZNavOLGae9z88pzp73P/fEI\nT5LUBANPktQEA0+S1AQDT5LUBANPktQEA0+S1AQDT5LUBANPktQEA0+S1AQDT5LUBANPktQEA0+S\n1AQDT5LUBANPktQEA0+S1AQDT5LUBANPktQEA0+S1AQDT5LUBANPktQEA0+S1AQDT5LUBANPktSE\nQYGX5KwkG5JsTLJinO2nJPlKkh8lefuQtkmOSXJzkm92z0cf/HQkSRrfpIGXZB5wJXA2cCpwQZJT\nx1R7ELgMuGIKbVcAt1TVEuCWbl2SpCfFkCO804CNVbWpqh4DrgWW9ytU1c6qWgc8PoW2y4FruuVr\ngPMOcA6SJE1qSOAtALb01rd2ZUPsr+1xVbW9W74fOG5gn5IkTdlT4qKVqiqgxtuW5OIk65Os37Vr\n1yEemSRprhgSeNuARb31hV3ZEPtruyPJCQDd887xOqiqq6tqWVUtmz9//sDdSpL0REMCbx2wJMnJ\nSQ4HzgfWDOx/f23XABd1yxcBnxs+bEmSpuawySpU1e4klwI3AfOA1VV1d5JLuu2rkhwPrAeeDexJ\ncjlwalU9NF7bruuVwHVJ3gjcB7x2uicnSdJekwYeQFWtBdaOKVvVW76f0enKQW278geAM6YyWEmS\nDtRT4qIVSZKebAaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQae\nJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSp\nCQaeJKkJBp4kqQkGniSpCQaeJKkJhw2plOQs4E+AecCHq2rlmO3ptp8DPAq8vqpuS/IC4M97VZ8P\n/GFVvT/Ju4DfB3Z1295ZVWsPZjLSU8niFTdOe5+bV5477X1KrZg08JLMA64EzgS2AuuSrKmqe3rV\nzgaWdI+XAVcBL6uqDcDSXj/bgBt67d5XVVdMx0QkSdqfIac0TwM2VtWmqnoMuBZYPqbOcuBjNfJV\n4KgkJ4ypcwbwraq676BHLUnSFA0JvAXAlt761q5sqnXOBz45puwtSe5IsjrJ0QPGIknSATkkF60k\nORx4NfCpXvFVjN7TWwpsB94zQduLk6xPsn7Xrl3jVZEkaVJDAm8bsKi3vrArm0qds4HbqmrH3oKq\n2lFVP66qPcCHGJ063UdVXV1Vy6pq2fz58wcMV5KkfQ0JvHXAkiQnd0dq5wNrxtRZA7wuI6cDP6iq\n7b3tFzDmdOaY9/heA9w15dFLkjTQpFdpVtXuJJcCNzH6WMLqqro7ySXd9lXAWkYfSdjI6GMJb9jb\nPskRjK7wfNOYrt+dZClQwOZxtkuSNG0GfQ6v+3zc2jFlq3rLBbx5graPAD83TvmFUxqpmjDdn13z\nc2uS9vJOK5KkJhh4kqQmGHiSpCYYeJKkJhh4kqQmGHiSpCYYeJKkJhh4kqQmGHiSpCYYeJKkJhh4\nkqQmGHiSpCYYeJKkJhh4kqQmGHiSpCYYeJKkJgz6AlhJT11z6Utzp3su4JcA66c8wpMkNcHAkyQ1\nwcCTJDXBwJMkNcHAkyQ1wcCTJDXBwJMkNcHAkyQ1wcCTJDVhUOAlOSvJhiQbk6wYZ3uSfKDbfkeS\nl/S2bU5yZ5Lbk6zvlR+T5OYk3+yej56eKUmStK9JAy/JPOBK4GzgVOCCJKeOqXY2sKR7XAxcNWb7\nr1bV0qpa1itbAdxSVUuAW7p1SZKeFEOO8E4DNlbVpqp6DLgWWD6mznLgYzXyVeCoJCdM0u9y4Jpu\n+RrgvCmMW5KkKRkSeAuALb31rV3Z0DoFfDHJrUku7tU5rqq2d8v3A8cNHrUkSVN0KL4t4RVVtS3J\nc4Gbk3yjqv6mX6GqKkmN17gLyYsBTjrppCd/tJLmPL+VoU1DjvC2AYt66wu7skF1qmrv807gBkan\nSAF27D3t2T3vHG/nVXV1VS2rqmXz588fMFxJkvY1JPDWAUuSnJzkcOB8YM2YOmuA13VXa54O/KCq\ntic5IsmRAEmOAF4J3NVrc1G3fBHwuYOciyRJE5r0lGZV7U5yKXATMA9YXVV3J7mk274KWAucA2wE\nHgXe0DU/Drghyd59/VlVfb7bthK4LskbgfuA107brCRJGmPQe3hVtZZRqPXLVvWWC3jzOO02AS+a\noM8HgDOmMlhJkg6Ud1qRJDXhUFylKWkOmO4rG72qUYeaR3iSpCYYeJKkJhh4kqQm+B7eLOcdIyRp\nGI/wJElNMPAkSU3wlKYkzWK+rTGcR3iSpCZ4hKfm+Bex1CaP8CRJTTDwJElNaPKUpvcElHQo+Lvm\nqcUjPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJUhMMPElSEww8SVITDDxJUhMMPElSEww8SVIT\nDDxJUhMMPElSEwYFXpKzkmxIsjHJinG2J8kHuu13JHlJV74oyV8luSfJ3Une2mvzriTbktzePc6Z\nvmlJkvREk349UJJ5wJXAmcBWYF2SNVV1T6/a2cCS7vEy4KrueTfwtqq6LcmRwK1Jbu61fV9VXTF9\n05EkaXxDjvBOAzZW1aaqegy4Flg+ps5y4GM18lXgqCQnVNX2qroNoKoeBu4FFkzj+CVJGmRI4C0A\ntvTWt7JvaE1aJ8li4MXA13rFb+lOga5OcvTAMUuSNGWH5KKVJM8CPg1cXlUPdcVXAc8HlgLbgfdM\n0PbiJOuTrN+1a9ehGK4kaQ4aEnjbgEW99YVd2aA6SZ7GKOw+UVWf2VuhqnZU1Y+rag/wIUanTvdR\nVVdX1bKqWjZ//vwBw5UkaV9DAm8dsCTJyUkOB84H1oypswZ4XXe15unAD6pqe5IAHwHurar39hsk\nOaG3+hrgrgOehSRJk5j0Ks2q2p3kUuAmYB6wuqruTnJJt30VsBY4B9gIPAq8oWv+cuBC4M4kt3dl\n76yqtcC7kywFCtgMvGnaZiVJ0hiTBh5AF1Brx5St6i0X8OZx2n0JyAR9XjilkUqSdBC804okqQkG\nniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4k\nqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJBp4kqQkGniSpCQaeJKkJ\nBp4kqQkGniSpCYMCL8lZSTYk2ZhkxTjbk+QD3fY7krxksrZJjklyc5Jvds9HT8+UJEna16SBl2Qe\ncCVwNnAqcEGSU8dUOxtY0j0uBq4a0HYFcEtVLQFu6dYlSXpSDDnCOw3YWFWbquox4Fpg+Zg6y4GP\n1chXgaOSnDBJ2+XANd3yNcB5BzkXSZImNCTwFgBbeutbu7IhdfbX9riq2t4t3w8cN3DMkiRNWapq\n/xWS3wDOqqrf69YvBF5WVZf26vwvYGVVfalbvwV4B7B4orZJvl9VR/X6+F5V7fM+XpKLGZ0mBXgB\nsOFAJ3sAjgW+ewj392SaS3OBuTWfuTQXmFvzmUtzgbk1n/5cnldV8ydrcNiATrcBi3rrC7uyIXWe\ntp+2O5KcUFXbu9OfO8fbeVVdDVw9YJzTLsn6qlo2E/uebnNpLjC35jOX5gJzaz5zaS4wt+ZzIHMZ\nckpzHbAkyclJDgfOB9aMqbMGeF13tebpwA+605X7a7sGuKhbvgj43FQGLknSVEx6hFdVu5NcCtwE\nzANWV9XdSS7ptq8C1gLnABuBR4E37K9t1/VK4LokbwTuA147rTOTJKlnyClNqmoto1Drl63qLRfw\n5qFtu/IHgDOmMtgZMCOnUp8kc2kuMLfmM5fmAnNrPnNpLjC35jPluUx60YokSXOBtxaTJDXBwBvH\nZLdSm02SLEryV0nuSXJ3krfO9JgOVpJ5Sf62+zjMrJbkqCTXJ/lGknuT/OJMj+lAJfk33b+xu5J8\nMsnTZ3pMU5FkdZKdSe7qlc3aWyBOMJ//3v1buyPJDUmO2l8fTxXjzaW37W1JKsmxk/Vj4I0x8FZq\ns8lu4G1VdSpwOvDmWT4fgLcC9870IKbJnwCfr6pTgBcxS+eVZAFwGbCsql7I6CK182d2VFP2UeCs\nMWWz+RaIH2Xf+dwMvLCqfgH4f8AfHOpBHaCPsu9cSLIIeCXwd0M6MfD2NeRWarNGVW2vqtu65YcZ\n/UIde6ecWSPJQuBc4MMzPZaDleQ5wC8DHwGoqseq6vszO6qDchjwjCSHAc8EvjPD45mSqvob4MEx\nxbP2FojjzaeqvlBVu7vVrzL6bPRT3gQ/G4D3Af8eGHQxioG3ryG3UpuVkiwGXgx8bWZHclDez+gf\n+J6ZHsg0OBnYBfyP7hTth5McMdODOhBVtQ24gtFf2tsZfRb3CzM7qmkxl2+B+LvAX8z0IA5UkuXA\ntqr6+tA2Bl4jkjwL+DRweVU9NNPjORBJXgXsrKpbZ3os0+Qw4CXAVVX1YuARZtcps5/o3ttazijE\nTwSOSPI7Mzuq6dV9/GpOXNae5D8wervjEzM9lgOR5JnAO4E/nEo7A29fQ26lNqskeRqjsPtEVX1m\npsdzEF4OvDrJZkanmv95ko/P7JAOylZga1XtPeK+nlEAzka/Bny7qnZV1ePAZ4BfmuExTYcd3a0P\n2d8tEGeTJK8HXgX8ds3ez6X9PKM/rr7e/T5YCNyW5Pj9NTLw9jXkVmqzRpIweo/o3qp670yP52BU\n1R9U1cKqWszo5/KXVTVrjyKq6n5gS5IXdEVnAPfM4JAOxt8Bpyd5Zvdv7gxm6QU4Y8ypWyAmOYvR\nWwKvrqpHZ3o8B6qq7qyq51bV4u73wVbgJd3/qQkZeGN0b+juvR3avcB1vduhzUYvBy5kdDR0e/c4\nZ6YHpZ94C/CJJHcAS4H/OsPjOSDdUer1wG3AnYx+t8yqu3ok+STwFeAFSbZ2tz1cCZyZ5JuMjmJX\nzuQYp2KC+XwQOBK4uftdsGq/nTxFTDCXqfcze49oJUkaziM8SVITDDxJUhMMPElSEww8SVITDDxJ\nUhMMPElSEww8SVITDDxJUhP+Pzq1yrQ9mM6xAAAAAElFTkSuQmCC\n",
      "text/plain": [
       "<matplotlib.figure.Figure at 0x164bdff21d0>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "f, ax = plt.subplots(figsize=(7, 5))\n",
    "ax.bar(range(len(rfc.feature_importances_)), rfc.feature_importances_)\n",
    "ax.set_title(\"Feature Importances\")\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 22,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "image/png": "iVBORw0KGgoAAAANSUhEUgAAAYoAAAEWCAYAAAB42tAoAAAABHNCSVQICAgIfAhkiAAAAAlwSFlz\nAAALEgAACxIB0t1+/AAAIABJREFUeJzt3Xd4VGX2wPHvAQSk2ABZBREUpAqIgKCIulhABRsq9vpD\nRMWyumJh1cWC67p2BUQFG3YBARU7WFBBOijSpIj03iTJ+f1xbswkJJNJyMydmZzP88xj5s6dO4cx\nmTNvO6+oKs4551xByoQdgHPOueTmicI551xUniicc85F5YnCOedcVJ4onHPOReWJwjnnXFSeKJwr\nQSJyvIgsjbg/S0SOj+XcYrzWQBHpV9znOxcrTxQuaYnIIhHZJiKbReQPERkqIlXynHO0iHwuIptE\nZIOIfCAiTfKcs5eIPC4ii4NrzQ/uV8/nNX8WkSvzOX6jiEwq6r9BVZuq6pdFfV4+r3+5iHyd59q9\nVLX/7l7bucJ4onDJrquqVgFaAkcAd2Q/ICLtgXHASOBAoB4wDfhGRA4JzikPfAY0BToDewHtgdVA\n23xebxhwaT7HLwkec67U8UThUoKq/gF8jCWMbP8BXlbVJ1R1k6quVdW7gYnAvcE5lwJ1gLNUdbaq\nZqnqSlW9X1XH5vNSrwAdROTg7ANBC6U5MDy4f4WIzAlaMQtE5JqC4g5aRScGP+8ZtIrWichsoE2e\nc/sGrZ1NIjJbRM4KjjcGBgLtgxbR+uD4UBG5P+L5/yci80RkrYiMEpEDIx5TEeklIr+KyHoReUZE\nJMpb7txfPFG4lCAitYEuwLzgfiXgaODtfE5/Czgp+PlE4CNV3RzL66jqUuALrAWR7RJgrKquDu6v\nBE7HWidXAI+JSKsYLn8PcGhwOwW4LM/j84Fjgb2B+4BXReQAVZ0D9AK+U9UqqrpP3guLyN+Bh4Dz\ngAOA34A38px2OpacmgfnnRJDzM55onBJb4SIbAKWYB/Q9wTH98N+f5fn85zlQPb4Q7UCzolmGEGi\nEJEywEVEdDup6hhVna/mK6z769gYrnse8EDQ8lkCPBn5oKq+raq/B62eN4Ffyb97LD8XAS+q6k+q\nugPromsvInUjzhmgqutVdTGWDFvuehnnduWJwiW7M1W1KnA80IicBLAOyMK+Ped1ADYGAbCmgHOi\neQ84QETaBa9bCRiT/aCIdBGRiUEXz3rg1Ii4ojkQS3jZfot8UEQuFZGpQdfQeqBZjNfNvvZf1wta\nUGuAWhHn/BHx81Yg18QA5wriicKlhOCb+1Dgv8H9LcB3wLn5nH4eNoAN8ClwiohULsJrbQXewcY3\nLgHeUNU/AUSkAvBuEEfNoBtoLBBLf/9y4KCI+3WyfwjGRJ4HrgeqBdedGXHdwso8/w5EjqtUxlpT\ny2KIy7moPFG4VPI4cJKItAju9wUuE5E+IlJVRPYNBnfbY338YIPTS4B3RaSRiJQRkWoicqeInBrl\ntYYB5wPnkHu2U3mgArAKyBCRLsDJMcb/FnBHEGdt4IaIxypjyWAV2IA51qLItgKoHcziys9w4AoR\naRkksweB71V1UYyxOVcgTxQuZajqKuBl4F/B/a+xAdmzsW/rv2FTaDuo6q/BOTuwAe2fgU+AjcAP\nWJfO91FebjywAViqqj9GxLAJ6IN96K8DLgRGxfhPuC+IcSE2rvFKxHVnA49iraQVwOHANxHP/RyY\nBfwhIqvJQ1U/BfphrZ3l2IB5jxjjci4q8Y2LnHPOReMtCuecc1HFLVGIyIsislJEZhbwuIjIk8EC\noekxzkN3zjmXYPFsUQzFSiYUpAvQILj1BJ6LYyzOOeeKKW6JQlXHA2ujnHIGVn5BVXUisI+IFHW+\nu3POuTgrF+Jr1yL34qOlwbFdVtGKSE+s1UHlypWPbNSoUUICdM65ZJGRYbedO3f9Oe+xzMyc5/2N\n5RzAH0wha7Wq1ijOa4eZKGKmqoOBwQCtW7fWSZOKXO3ZOeeShips3gwrV+56W7Vq12OrV+f+8M8m\nAvvtBwccAPvvn3OrUQP2r6HsX1NoNHcUB84cx36vP/PbrleITZiJYhm5V6nWxleROudS1PbtBX/Q\n53dsx478r7PXXjkf9occAu3a5UkAEQmhWjUol/dTfN06uPVWKHcI9L4L6Ga3158p9r8tzEQxCrhe\nRN4AjgI2qGpRi7c551xcZGTYN/loH/aRxzZtyv86FSpAzZo5H+7NmuX+sI9MADVqQMWKuxH0++9D\n794W2N1378aFcotbohCR4VhBterBdo/3AHsAqOpArD7OqVjZ6K1YuWbnnIuLrCxYv77wb/rZx9es\nyf86Zcvm/mZ/1FG7ftOP/PCvUsW6iOJqxQq44QZ4+21o2RLGjIFWJbfiIG6JQlUvKORxBa6L1+s7\n59Jbdj9/rF09q1dbKyE/1arlfLBHfuPPLwHssw+USbalykuWWHJ44AG47TbYY48SvXxKDGY750qH\n7dtzPuRjSQDbt+d/napVcz7Y69aFtm3z/7af3c9fwp+rifHbb/DBB3D99dC6NSxebP+YOPBE4ZyL\nm4wM68KJtZ9/48b8r1OhQu4P+qZNC+7uqVED9twzsf/OhMrKgueeg7597f4559i0pzglCfBE4Zwr\nAtVd+/mjJYA1a+w5eWX382d/2LdpE727JyH9/Kngl1/g6qvh66/hlFNg0CBLEnHmicK5UkwVtmyJ\nPqib935B/fz77Zfzwd6kScGDu/vvD/vum4T9/Mlu61bo0MEWVAwdCpdemrDs6YnCuTSzY0fR+vm3\nbcv/OlWq5HywH3ywfesvqLunevUU7edPBXPnQoMGUKkSvPKKzWr6298SGoInCueSXGZm7n7+whLA\nhg35X6d8eZvPn/1h37hxwd09ad/Pnwq2b4f+/eHhh60FcfHF0DlandX48UThXIKp2od5LP38K1cW\n3M9fpkzuD/gjj4ze3VO1qvfzp4xvvoGrrrIxiSuugNNOCzUcTxTOlYAtW2Lv6lm1ygq35WfffXM+\n2Bs3huOOK7i7Z7/9vJ8/LfXvD/fcA3XqwMcfw8mxbskeP54onCuiP/6ASZNy31asyP/c7H7+GjXg\noINyf+vPmwC8n7+UU7UmX8uWtsr6gQfsFygJeKJwLoqVK2Hy5JyEMHkyLAtKV5YpY7N7One2b//Z\n9Xwi6/ZUqhRu/C4FrF0LN98M9etDv37QtavdkognCucCa9fmTgqTJtliV7Aveg0bwgkn2CLY1q3t\ni1/lyuHG7FLcO+/AddfZL1+/fmFHUyBPFK5UWr8efvopd1JYuDDn8QYN4Jhj4MYbrbvoiCOs/LNz\nJWL5ciu98d579gs2bhy0aBF2VAXyROHS3saNMGVK7u6jX3/NebxePWsh9Opl/23Vygq/ORc3v/9u\nA9UPPwy33JLPphLJJbmjc66ItmyxpBDZhfTLLznTS+vUsWRwxRU5SSGOJXKcy7FokRXxu+EGa0Us\nWWLT3FKAJwqXsrZtg2nTcncfzZljNdMAatWyZHDhhfbf7BlHziVUZiY88wzceafNgDj3XFtZnSJJ\nAjxRuBSxYwdMn547KcyalbOPcM2algy6d89JCgmoleZcdHPmWBG/b7+16XGDBiW8/EZJ8EThks6f\nf8LMmbm7j2bMyFmkVr26JYNu3XKSQq1avurYJZmtW6FjR2vivvyyleBI0V9STxQuVBkZMHt27pbC\ntGmWLMBa50ceCf/4R8601Dp1UvbvzZUGP/9sc6krVYLXXrPZTDVrhh3VbvFE4RImM9P+hiJnH02Z\nkrNL2V57WVK48cacpFCvnicFlyK2bYN774X//heGDbMWRBKU3ygJnihcXGRlWXXk7IQwaZKtW9i6\n1R6vXNmSQu/e9t/WrW1hqtcucilp/Hgbi/j1V/vv6aeHHVGJ8kThdpsqzJ+fu/vop59g0yZ7fM89\nbcHa1VfntBQOO8x2OXMu5d13n7Uk6tWDTz+FTp3CjqjEeaJwRaJq08HzJoX16+3xChWstMWll+Yk\nhUaNkn49kXNFl13Er3Vrq9XUv3/a1nTxP19XIFVbE5S3/tHatfb4HnvYON355+ckhaZNvQKqS3Or\nV1tiaNAA/vUv2ysi5P0i4s0ThfvL77/vWj571Sp7rFw5aNYMzj47Jyk0a2YtCOdKBVV4+22r0bRu\nne0ZUUp4oiilVqzInRAmT7Y6ZWADyk2b2nhcdlJo3hwqVgw3ZudC8/vvNvNi5Ej7g/j0U/ujKCU8\nUZQSM2fa73h2Yli61I6L2BjCiSfmLp/t+yg4F+GPP+Dzz+GRR+Cmm0rdoFvp+teWMtu3w7vvwnPP\n2Ra8YLONOnbMnRSqVg03TueS0oIFMGqUJYZWrWxzklJaVtgTRRqaP99Kyrz0ko27HXqofRG67DLb\ndc05F0VmJjz5JNx1l83M6NHD6jOV0iQBnijSRkYGjB5trYdx42yNQrducO21Nq3bF7I5F4NZs+Cq\nq+D7720m08CBKVnEr6R5okhxy5bBkCHw/PP2c61atvbn6qvtZ+dcjLZuheOOs4G711+3loTXjwE8\nUaSkrCz47DNrPYwaZS3lU06Bp5+2mUqlbJzNud0zezY0bmwzON54wxYHeR9tLt4hkUJWr7Z6Yw0b\nWq2x8eNtF8V58+Cjj+DMMz1JOBezrVvhttvg8MPh1Vft2IknepLIh3+sJDlV2/Nk4EBb67NjB3To\nYN1L55zjaxucK5Yvv4T/+z/7lnXNNTag5wrkiSJJbdxopeyfe8427ala1cYdrrnGvgA554rpnnvg\n3/+26YCffw4nnBB2REnPE0WSmTrVWg+vvQabN9s6h0GDbN/nKlXCjs65FJZdxK9tW9sJ69//9pWl\nMYrrGIWIdBaRX0Rknoj0zefxvUXkAxGZJiKzROSKeMaTrLZts50S27e3ctzDhtnezxMnWmXWnj09\nSThXbKtW2Tetf//b7p92mg32eZKIWdwShYiUBZ4BugBNgAtEpEme064DZqtqC+B44FERKR+vmJLN\n3Ln2xaZ2bVsMt24dPPaYTXN96SU46iifnedcsanaNNfGjeGdd6B8qfloKXHx7HpqC8xT1QUAIvIG\ncAYwO+IcBaqKiABVgLVARhxjCt3OnTal9bnnbIpruXJw1lnQq5d1lXpicK4ELF1qq01Hj7ZvXC+8\nYJUuXbHEM1HUApZE3F8KHJXnnKeBUcDvQFXgfFXNynshEekJ9ASoU6dOXIKNtyVLbFHckCFWpbVO\nHbj/frjySjjggLCjcy7NrFpl88f/9z/o08e3U9xNYQ9mnwJMBf4OHAp8IiITVHVj5EmqOhgYDNC6\ndWtNeJTFlJUFH39sg9OjR1tLuEsXG5w+9VT/3XWuRM2bBx98YJsKHXGEfTvba6+wo0oL8RzMXgYc\nFHG/dnAs0hXAe2rmAQuBRnGMKSFWroSHH4b69S0hTJwIt99uxfrGjIGuXT1JOFdiMjJscPrww23/\n6hUr7LgniRITz0TxI9BAROoFA9Q9sG6mSIuBTgAiUhNoCCyIY0xxNX26Ta6oXRv69rXupeHD7YvN\ngw/a3uvOuRI0YwYcfbStsD75ZCvqV7Nm2FGlnbh1PalqhohcD3wMlAVeVNVZItIreHwg0B8YKiIz\nAAFuV9XV8YopXjIz7QtNv3424+7aa21hXJO8c7yccyVn61abAVKmjNVoOu88nw0SJ3Edo1DVscDY\nPMcGRvz8O3ByPGOIt99+g0svtXGzc86x8Ydq1cKOyrk0NnOmzWCqVAnefNOK+FWvHnZUac2LAhaT\nqq2ebt4cpkyBoUOtFpMnCefiZMsWq4LZvHlOEb9OnTxJJEDYs55S0rp11r305ptwzDHwyis+/uBc\nXH32mRXxW7gQeveGM84IO6JSxVsURfT55/aF5t134YEH4KuvPEk4F1f9+ln573Ll7A/umWd8RlOC\neaKI0Y4dcOut1tKtVAm++w7uvNOnuToXN1nB2tujj4Z//hOmTYOOHcONqZTyRBGDGTOgTRt49FHr\ncvrpJ2jdOuyonEtTK1faNqT33Wf3u3SxhUl77hluXKWYJ4oosrKsSF/r1raGZ/RoePZZqFw57Mic\nS0OqNkjduDG8/75Xd00iPphdgKVL4fLLbQytWzer07T//mFH5VyaWrLEKmOOHWv19ocM8YVIScRb\nFPl46y2rBvDddzB4MIwY4UnCubhaswa++QaeeAImTPAkkWS8RRFhwwa44Qab7tq2rbWCGzQIOyrn\n0tTcuVZz/9ZbbSvHJUtsz1+XdLxFEZgwwRZ4vv66ban79deeJJyLi4wMG5xu3tzmmGcX8fMkkbQ8\nUQAPPQTHHWfTtCdMgHvvhT32CDsq59LQtGm2kVDfvlZaefZsL+KXAkp919O4cbYe4vzzbcDav9Q4\nFydbt9pCpHLlbGvSc84JOyIXo1KdKNavh6uustl4Q4dCxYphR+RcGpo+3WaHVKpkBdFatID99gs7\nKlcEpbrr6aabbFvSYcM8SThX4jZvhhtvtIHqV16xYyec4EkiBZXaFsWoUZYg+vWzVdfOuRL0ySfQ\nsycsWgTXXw9nnRV2RG43xNSiEJHyIlI/3sEkyurV9jvcsiXcfXfY0TiXZu66y3abq1DBZoc89ZQP\n/qW4QhOFiJwGzAA+Ce63FJH34x1YPF13Haxday2K8uXDjsa5NJFdxK9DB7jjDpg61X52KS+WFsW/\ngaOA9QCqOhVI2dbFm2/ayuv77rNp3M653fTHH9C9u80rByvi9+CDPvCXRmJJFDtVdX2eYxqPYOLt\njz9sz5OjjrK92J1zu0HVpgs2aWIVM32PiLQVy2D2HBE5DygjIvWAPsDE+IZV8lRtg6ytW63LqVyp\nHcZ3rgT89psN9I0bZ91LQ4ZAw4ZhR+XiJJYWxfXAkUAW8B6wA7gxnkHFw7Bh9qXnoYf899m53bZ+\nPfz4Izz9tO06539UaU1Uo/ciicjZqvpeYccSpXXr1jpp0qQiPWfxYlvvc8QRtpVpmVK9esS5Yvrl\nF5tXnt1vu3kzVKkSbkwuZiIyWVWLteVaLB+Z+U0gvas4LxYGVVt9nZkJL73kScK5Itu505riLVrA\ngAG2Ax14kihFCuypF5FTgM5ALRH5X8RDe2HdUClh4ED49FP7b716YUfjXIqZMsW+aU2ZYjObnn7a\nN2cphaIN6a4EZgLbgVkRxzcBfeMZVEmZP99K3Z98so27OeeKYOtWOOkkK6X87rtw9tlhR+RCUmCi\nUNUpwBQReU1VtycwphKRmWlbme6xB7zwAoiEHZFzKWLKFCtbUKmSVXlt0QL23TfsqFyIYumxryUi\nb4jIdBGZm32Le2S76amnbPOhp56C2rXDjsa5FLBpk9VlatUqp4jf8cd7knAxJYqhwEuAAF2At4A3\n4xhTiXj2WduM6OKLw47EuRTw0UfQrJn94dx4o3czuVxiSRSVVPVjAFWdr6p3Ywkjaf36q926d/cu\nJ+cKdccdVnajcmX45ht4/HGf0eRyiWV98g4RKQPMF5FewDIgqUtBjhlj/z3ttHDjcC6pZWZC2bLW\nvVSunJVSrlAh7KhcEoolUdwMVMZKdzwA7A1cGc+gdtfo0VZ+xqfDOpeP5cuthHLTptC/P5xyit2c\nK0ChXU+q+r2qblLVxap6iap2AxbFP7Ti2bQJxo/31oRzu1C1VadNmsCHH/ogtYtZ1EQhIm1E5EwR\nqR7cbyoiLwPfJyS6YvjkE1tIevrpYUfiXBJZtMgWFF15pdWzmTYNbrkl7KhciigwUYjIQ8BrwEXA\nRyJyL/AFMA04LCHRFcPo0bDPPnD00WFH4lwS2bABfvrJZjV9+SUclrR/wi4JRRujOANooarbRGQ/\nYAlwuKouiPXiItIZeAIoCwxR1QH5nHM88DiwB7BaVY8rQvy5ZGXB2LHW3eplxF2pN3u2FfHr29cW\nzS1ebDObnCuiaF1P21V1G4CqrgXmFjFJlAWewabSNgEuEJEmec7ZB3gW6KaqTYFzixh/LpMnw4oV\n3u3kSrk//4T777dyyf/9b04RP08Srpiife8+RESyS4kLUC/iPqpa2IqctsC87OQiIm9grZTZEedc\nCLynqouDa64sYvy5jBlj6yY6d96dqziXwiZNsiJ+06dDjx7wxBNexM/ttmiJ4pw8958u4rVrYd1V\n2ZZie29HOgzYQ0S+xNZmPKGqL+e9kIj0BHoC1KlTp8AXHDMG2rWD6tWLGKlz6WDLFut3rVgRRo6E\nbt3CjsiliWhFAT9L0OsfCXQC9gS+E5GJqpqrlpSqDgYGg21clN+Fli+3L1MPPBDniJ1LNj/9ZEX8\nKleG99+H5s1tRodzJSSe2/gsAw6KuF87OBZpKfCxqm5R1dXAeKBFcV7sww/tv75+wpUaGzdC795w\n5JHw6qt2rGNHTxKuxMUzUfwINBCReiJSHugBjMpzzkigg4iUE5FKWNfUnOK82JgxViW2efPditm5\n1DB2rK2sHjTI1kOck7en2LmSE3OiEJEiFYFR1QzgeuBj7MP/LVWdJSK9gppRqOoc4CNgOvADNoV2\nZlFeB2DHDhg3zloTXgTQpb3bb7df9r32gm+/hUcf9RlNLq4KXW0gIm2BF7AaT3VEpAVwtareUNhz\nVXUsMDbPsYF57j8CPFKUoPOaMMH2efduJ5e2VG2hUNmy0KmTDVjfeacX8XMJEUuL4kngdGANgKpO\nA06IZ1BFNWaM/b38/e9hR+JcHCxbBmeeCffcY/dPPhnuu8+ThEuYWBJFGVX9Lc+xzHgEU1yjR1uS\n8Na3Syuq8PzzVsRv3Dif9+1CE0uiWBJ0P6mIlBWRm4Ck2Qp17lyYN8+7nVyaWbjQuph69rStSWfM\ngJtuCjsqV0rFkiiuBW4B6gArgHbBsaTgmxS5tLR5s62uHjQIPvsM6tcPOyJXisVSOi9DVXvEPZJi\nGj3aZgnWrRt2JM7tppkzrYjfnXdaKfDFi6FSpbCjci6mFsWPIjJWRC4TkaTaAnXjRt+kyKWBP/+0\nwelWreCxx3KK+HmScEkilh3uDgXux0ptzBCRESKSFC2Mzz+HjAw49dSwI3GumH780VZW33svnHuu\nlQb3In4uycS04E5Vv1XVPkArYCO2oVHoxo+36eTt2oUdiXPFsGWLlTpet866nF57DWrUCDsq53ZR\naKIQkSoicpGIfICtnl4FJMX+cV99ZUnCp5O7lDJpki2eq1zZqrzOmgVdu4YdlXMFiqVFMROb6fQf\nVa2vqv9Q1dD3zN6wAaZOheOKvR+ecwm2YQNccw20aZNTxK9DB9h773Djcq4Qscx6OkRVs+IeSRF9\n+619KevYMexInIvBBx9Ar17wxx9w663QvXvYETkXswIThYg8qqr/AN4VkV32gIhhh7u4Gj/e9sX2\n8QmX9G67zbYkPfxwGDHCWhTOpZBoLYo3g/8WdWe7hBg/3v7efAahS0qqkJlp32ZOPtkqvd5+O5Qv\nH3ZkzhVZgWMUqvpD8GNjVf0s8gY0Tkx4+du61WYVereTS0pLl9o2pNlF/E46Cfr18yThUlYsg9lX\n5nPsqpIOpCi+/x527vRE4ZJMVpaV3GjSxBb5/O1vYUfkXImINkZxPrYrXT0ReS/ioarA+ngHFs34\n8bZB0THHhBmFcxEWLIArr7Q52506weDBcMghYUflXImINkbxA7YHRW3gmYjjm4Ap8QyqMOPH217y\nPqvQJY0tW2xV9ZAhljB8q0WXRgpMFKq6EFgIfJq4cGLz3Xdw9dVhR+FKvRkzbMHc3XfbjKbffoM9\n9ww7KudKXIFjFCLyVfDfdSKyNuK2TkTWJi7E3FRh2zbv/nUh2rED/vUvK+L35JM5Rfw8Sbg0Fa3r\nKXu706TaVisrWPrnZTtcKCZOhKuusm6mSy6xaq/VqoUdlXNxFa3rKXs19kHA76r6p4h0AJoDr2LF\nARNOg6V/FSuG8equVNuyxWraV64MY8dCly5hR+RcQsQyPXYEtg3qocBLQAPg9bhGFYW3KFzCff99\nThG/Dz6wIn6eJFwpEkuiyFLVncDZwFOqejNQK75hFSy7ReGJwsXd+vU2a6Jdu5wifkcfDVWTav8u\n5+Iupq1QReRc4BLgzODYHvELKTpvUbiEGDECeve2gerbb7dNhZwrpWJdmX0CVmZ8gYjUA4bHN6yC\neYvCxd0tt8BZZ9lOc99/DwMG+IwmV6oV2qJQ1Zki0geoLyKNgHmq+kD8QysoHvuvJwpXoiKL+J16\nqs1k+uc/YY/QGs/OJY1CE4WIHAu8AiwDBPibiFyiqt/EO7j8ZHc9+awnV2IWL7a9Io44Ah54AE48\n0W7OOSC2rqfHgFNV9RhVPRo4DXgivmEVzFsUrsRkZcGzz0LTplaj6cADw47IuaQUy2B2eVWdnX1H\nVeeISGj1kn0w25WIefOsJtOECVYGfPBgqFs37KicS0qxJIqfRGQgtsgO4CJCLAroLQpXIrZvh7lz\n4aWX4LLLvIifc1HEkih6AX2Afwb3JwBPxS2iQniLwhXb1KlWxO+ee6BZM1i0yAe7nItB1EQhIocD\nhwLvq+p/EhNSdN6icEW2fTv07w8PPwzVq8O119rUV08SzsUkWvXYO7HyHRcBn4hIfjvdJZy3KFyR\nfPutzWZ68EG4+GIr5rf//mFH5VxKidaiuAhorqpbRKQGMBZ4MTFhFcyLArqYbdkCXbtClSrw0Udw\nyilhR+RcSoqWKHao6hYAVV0lIrFMpY0773pyhfruOzjqKCviN3q0jUd4fSbnii3ah/8hIvJecHsf\nODTi/ntRnvcXEeksIr+IyDwR6RvlvDYikiEi3Qu7ZnbXU/nQJui6pLVunU15PfpoeOUVO9a+vScJ\n53ZTtBbFOXnuP12UC4tIWWyv7ZOApcCPIjIqck1GxHkPA+Niua6qJQmfzehyee89uO46WLUK7rgD\nzj8/7IicSxvRNi76bDev3RarC7UAQETeAM4AZuc57wbgXaBNLBfNyvJuJ5fHzTfD449Dy5a2odAR\nR4QdkXNpJZZ1FMVVC1gScX8pcFTkCSJSCzgLq05bYKIQkZ5AT4AqVZr4QLbLXcTv9NNtJtOtt3oR\nP+fiIOwB6seB2yO2Xc2Xqg5W1daq2rpChT09UZR2ixZB587Qr5/d79TJups8STgXFzEnChEpaofP\nMmy/7WwXtj+GAAAVmUlEQVS1g2ORWgNviMgioDvwrIicSRSq3vVUamVlwVNP2Symb7+Fgw8OOyLn\nSoVCE4WItBWRGcCvwf0WIhJLCY8fgQYiUi8oItgDGBV5gqrWU9W6qloXeAforaojol3UxyhKqV9/\nhY4doU8fOPZYmDnTSoM75+IulhbFk8DpwBoAVZ2GjSlEpaoZwPXAx8Ac4C1VnSUivUSk2H/h3qIo\npf78E+bPh5dftgFrb004lzCxDGaXUdXfJPd81MxYLq6qY7EV3ZHHBhZw7uWxXNNbFKXIlClWxO/e\ne23PiEWL/H++cyGIpUWxRETaAioiZUXkJmBunOMqkLcoSoHt221wuk0bGDTI1kaA/493LiSxJIpr\ngVuAOsAKoF1wLBSqXucprX39NbRoAQMGwKWXWhG/GjXCjsq5Uq3QridVXYkNRCcF73pKY5s3wxln\nwF57wbhxtvOccy50hSYKEXke0LzHVbVnXCIqhHc9paGvv7b6TFWqwJgxNv21SpWwo3LOBWLpevoU\n+Cy4fQPsD+yIZ1DReIsijaxZY91Lxx6bU8SvXTtPEs4lmVi6nt6MvC8irwBfxy2iQniLIg2owjvv\nwPXXw9q1tsK6R9L0bjrn8ihOrad6QM2SDiRW3qJIAzffDE88AUceaWMRLVqEHZFzLopYxijWkTNG\nUQZYCxS4t0S8eYsiRalCRobVY+rWDQ48EG65xYr6OeeSWtS/UrFVdi3IqdGUpaq7DGwnkk+PTUEL\nF0LPntaCGDAA/v53uznnUkLUwewgKYxV1czgFmqSsJi8RZEyMjOti6lZM/j+ezjkkLAjcs4VQyyz\nnqaKSFLtBOOJIgXMnWuzmW66CY47DmbNslaFcy7lFNj1JCLlgsJ+R2DbmM4HtgCCNTZaJSjGXXii\nSAEZGfDbb/Dqq3Dhhb53rXMpLNoYxQ9AK6BbgmKJmSeKJDVpkhXx698fmjSBBQv8f5ZzaSBa15MA\nqOr8/G4Jii9f/tmTZLZtg3/+E446Cl580Yv4OZdmorUoaojILQU9qKr/i0M8MfFZT0nkq6/g6qth\n3jz4v/+D//wH9tkn7KiccyUoWqIoC1QhaFkkE/+imiQ2b4azz7bE8NlnPuXVuTQVLVEsV9V/JyyS\nIvAWRcgmTIBjjrGaTB9+aJsKVa4cdlTOuTgpdIwiGXmiCMnq1XDxxbZ3dXYRv7ZtPUk4l+aitSg6\nJSyKIvKupwRThbfeghtugHXr4J57vIifc6VIgYlCVdcmMpCi8BZFgt14Izz1lG1N+tlncPjhYUfk\nnEuglKzI5okiAVRh504oXx7OOgsOPthWWZctG3ZkzrkEi6WER9LxRBFn8+dDp05w9912/4QT4B//\n8CThXCmVkonCxyjiJDMT/vc/61qaPBkaNgw7IudcEvCuJ2d+/hkuuwx++AG6doXnnoNatcKOyjmX\nBDxROJOVBb//DsOHw/nnexE/59xfPFGUZj/8YEX8HnjAivjNn2+D1845FyElxyj22CPsCFLc1q1w\n663Qvj0MG5ZTxM+ThHMuHymXKES8V2S3fPGFDVY/+qgV8Zs1C2rUCDsq51wSS7muJ08Su2HzZjj3\nXCvi98UXcPzxYUfknEsBKdeicMXw5Zc2WJ1dxG/6dE8SzrmYeaJIZ6tWwQUX2IK5V1+1Y23aQKVK\n4cblnEspKdf15GKgatNc+/SBTZtsa1Iv4uecKyZPFOnohhvgmWegXTt44QWb+uqcc8XkiSJdZGVB\nRoZNce3eHerXt4Th9Zmcc7sprmMUItJZRH4RkXki0jefxy8SkekiMkNEvhWRFvGMJ239+qttQ3rX\nXXb/+OO90qtzrsTELVGISFngGaAL0AS4QETy9oEsBI5T1cOB/sDgeMWTljIy4L//hebNYepUaNw4\n7Iicc2konl1PbYF5qroAQETeAM4AZmefoKrfRpw/Eagdx3jSy5w5cOmlMGkSnHEGPPssHHhg2FE5\n59JQPLueagFLIu4vDY4V5Crgw/weEJGeIjJJRCapagmGmOJWrIA334T33/ck4ZyLm6QYzBaRE7BE\n0SG/x1V1MEG3VNmyrUtvppg40Yr4PfSQdTPNn++Fr5xzcRfPFsUy4KCI+7WDY7mISHNgCHCGqq6J\nYzypa8sWuPlmOPpoeO21nCJ+niSccwkQz0TxI9BAROqJSHmgBzAq8gQRqQO8B1yiqnPjGEvq+vRT\naNYMHn8cevf2In7OuYSLW9eTqmaIyPXAx0BZ4EVVnSUivYLHBwL/AqoBz4pV+8tQ1dbxiinlbN5s\nK6r32w/Gj4djjw07IudcKSSpNjhctmxrzcycFHYY8fX553DccbYOYvJkW1m9555hR+WcS2EiMrm4\nX8S9KGAyWbECzjsPOnXKKeJ35JGeJJxzofJEkQxU4ZVXrOWQvTXphReGHZVzzgFJMj221LvuOnju\nOdua9IUXfIW1cy6peKIIS1YW7NwJFSrA+edbcujd2+szOeeSjnc9heGXX2ywOruI33HHeaVX51zS\n8kSRSDt3woAB0KIFzJwJhx8edkTOOVco73pKlFmz4JJLYMoUOPts21job38LOyrnnCuUJ4pEKVsW\n1q6Fd96Bc84JOxrnnIuZdz3F07ffwu2328+NGsG8eZ4knHMpxxNFPGzeDH36QIcOVgZ89Wo7Xs4b\ncM651OOJoqSNG2dF/J5+Gq6/3gatq1cPOyrnnCs2/4pbkjZvhosugmrVYMIEOOaYsCNyzrnd5i2K\nkvDJJ5CZCVWqWIti6lRPEs65tOGJYncsX26D0yefbBsKARxxBFSsGG5czjlXgjxRFIcqDB1qRfzG\njLFFdF7EzzmXpnyMojiuvRYGDbJZTUOGQMOGYUfkXFLauXMnS5cuZfv27WGHUmpUrFiR2rVrs0cJ\nbpXsiSJWkUX8LrwQmjeHXr2gjDfKnCvI0qVLqVq1KnXr1iXYxdLFkaqyZs0ali5dSr169Ursuv4p\nF4s5c2wb0jvvtPsdO1qlV08SzkW1fft2qlWr5kkiQUSEatWqlXgLzj/potm5Ex58EFq2hJ9/toFq\n51yReJJIrHi83971VJBZs+Dii22q67nnwlNPQc2aYUflnHMJ5y2KgpQrBxs2wHvvwVtveZJwLoWN\nGDECEeHnn3/+69iXX37J6aefnuu8yy+/nHfeeQewgfi+ffvSoEEDWrVqRfv27fnwww93O5aHHnqI\n+vXr07BhQz7++ON8z5k2bRrt27fn8MMPp2vXrmzcuLFIzy9pnigiTZgAt95qPzdsCHPnwllnhRuT\nc263DR8+nA4dOjB8+PCYn9OvXz+WL1/OzJkz+emnnxgxYgSbNm3arThmz57NG2+8waxZs/joo4/o\n3bs3mZmZu5x39dVXM2DAAGbMmMFZZ53FI488UqTnlzTvegLYtAn69oVnn4V69ezn6tW9iJ9zJeim\nm6wntyS1bAmPPx79nM2bN/P111/zxRdf0LVrV+67775Cr7t161aef/55Fi5cSIUKFQCoWbMm5513\n3m7FO3LkSHr06EGFChWoV68e9evX54cffqB9+/a5zps7dy4dO3YE4KSTTuKUU06hf//+MT+/pHmL\n4sMPoWlTeO45+02eMcOL+DmXRkaOHEnnzp057LDDqFatGpMnTy70OfPmzaNOnTrstddehZ578803\n07Jly11uAwYM2OXcZcuWcdBBB/11v3bt2ixbtmyX85o2bcrIkSMBePvtt1myZEmRnl/SSvdX5k2b\n4NJLYf/9be+Idu3Cjsi5tFXYN/94GT58ODfeeCMAPXr0YPjw4Rx55JEFzg4q6qyhxx57bLdjzOvF\nF1+kT58+9O/fn27dulG+fPkSf42iKH2JQhU+/hhOOgmqVoVPP7VNhYLmpXMufaxdu5bPP/+cGTNm\nICJkZmYiIjzyyCNUq1aNdevW7XJ+9erVqV+/PosXL2bjxo2Ftipuvvlmvvjii12O9+jRg759++Y6\nVqtWrb9aB2ALEmvVqrXLcxs1asS4ceMA64YaM2ZMkZ5f4lQ1pW5lyhypxfb776pnnqkKqsOGFf86\nzrmYzJ49O9TXHzRokPbs2TPXsY4dO+pXX32l27dv17p16/4V46JFi7ROnTq6fv16VVW97bbb9PLL\nL9cdO3aoqurKlSv1rbfe2q14Zs6cqc2bN9ft27frggULtF69epqRkbHLeStWrFBV1czMTL3kkkv0\nhRdeKNLz83vfgUla3M/d+KeiJKAKL74IjRvDRx/Bf/7jRfycKwWGDx/OWXlmLp5zzjkMHz6cChUq\n8Oqrr3LFFVfQsmVLunfvzpAhQ9h7770BuP/++6lRowZNmjShWbNmnH766TGNWUTTtGlTzjvvPJo0\naULnzp155plnKFu2LGAznSZNmvRX3IcddhiNGjXiwAMP5Iorrij0+fEklmhSR9myrTUzc1LRnnTN\nNTB4sJXeGDIEGjSIT3DOuVzmzJlD48aNww6j1MnvfReRyaraujjXS98xisxMK8FRsaKtsD7iCOjZ\n0+szOedcEaXnp+asWbbDXHYRv2OP9UqvzjlXTOn1yfnnn9C/v7Ue5s2DNm3Cjsi5Ui/VurdTXTze\n7/TpepoxAy66yP7bowc8+STUqBF2VM6VahUrVmTNmjVeajxBNNiPomIJb8ecPomifHnYuhVGjoRu\n3cKOxjmHrRxeunQpq1atCjuUUiN7h7uSlNqznr76CkaNgkcftfuZmZCAqWLOOZdqdmfWU1zHKESk\ns4j8IiLzRKRvPo+LiDwZPD5dRFrFdOGNG23f6uOPhxEjYPVqO+5JwjnnSlzcEoWIlAWeAboATYAL\nRKRJntO6AA2CW0/gucKuu5dusCJ+gwfDLbd4ET/nnIuzeLYo2gLzVHWBqv4JvAGckeecM4CXgxXm\nE4F9ROSAaBc9WBfB3ntbEb9HH4VKleISvHPOORPPwexawJKI+0uBo2I4pxawPPIkEemJtTgAdsis\nWTO90isA1YHVYQeRJPy9yOHvRQ5/L3I0LO4TU2LWk6oOBgYDiMik4g7IpBt/L3L4e5HD34sc/l7k\nEJEi1j7KEc+up2XAQRH3awfHinqOc865EMUzUfwINBCReiJSHugBjMpzzijg0mD2Uztgg6ouz3sh\n55xz4Ylb15OqZojI9cDHQFngRVWdJSK9gscHAmOBU4F5wFbgihguPThOIacify9y+HuRw9+LHP5e\n5Cj2e5FyC+6cc84lVnoVBXTOOVfiPFE455yLKmkTRdzKf6SgGN6Li4L3YIaIfCsiLcKIMxEKey8i\nzmsjIhki0j2R8SVSLO+FiBwvIlNFZJaIfJXoGBMlhr+RvUXkAxGZFrwXsYyHphwReVFEVorIzAIe\nL97nZnE3247nDRv8ng8cApQHpgFN8pxzKvAhIEA74Puw4w7xvTga2Df4uUtpfi8izvscmyzRPey4\nQ/y92AeYDdQJ7u8fdtwhvhd3Ag8HP9cA1gLlw449Du9FR6AVMLOAx4v1uZmsLYq4lP9IUYW+F6r6\nraquC+5OxNajpKNYfi8AbgDeBVYmMrgEi+W9uBB4T1UXA6hqur4fsbwXClQV2xSjCpYoMhIbZvyp\n6njs31aQYn1uJmuiKKi0R1HPSQdF/XdehX1jSEeFvhciUgs4ixgKTKa4WH4vDgP2FZEvRWSyiFya\nsOgSK5b34mmgMfA7MAO4UVWzEhNeUinW52ZKlPBwsRGRE7BE0SHsWEL0OHC7qmb5jmqUA44EOgF7\nAt+JyERVnRtuWKE4BZgK/B04FPhERCao6sZww0oNyZoovPxHjpj+nSLSHBgCdFHVNQmKLdFieS9a\nA28ESaI6cKqIZKjqiMSEmDCxvBdLgTWqugXYIiLjgRZAuiWKWN6LK4ABah3180RkIdAI+CExISaN\nYn1uJmvXk5f/yFHoeyEidYD3gEvS/Ntioe+FqtZT1bqqWhd4B+idhkkCYvsbGQl0EJFyIlIJq948\nJ8FxJkIs78VirGWFiNTEKqkuSGiUyaFYn5tJ2aLQ+JX/SDkxvhf/AqoBzwbfpDM0DStmxvhelAqx\nvBeqOkdEPgKmA1nAEFXNd9pkKovx96I/MFREZmAzfm5X1bQrPy4iw4HjgeoishS4B9gDdu9z00t4\nOOeciypZu56cc84lCU8UzjnnovJE4ZxzLipPFM4556LyROGccy4qTxQu6YhIZlDxNPtWN8q5dQuq\nlFnE1/wyqD46TUS+EZGGxbhGr+wyGSJyuYgcGPHYEBFpUsJx/igiLWN4zk3BOgrnisUThUtG21S1\nZcRtUYJe9yJVbQEMAx4p6pODtQsvB3cvBw6MeOxqVZ1dIlHmxPksscV5E+CJwhWbJwqXEoKWwwQR\n+Sm4HZ3POU1F5IegFTJdRBoExy+OOD5IRMoW8nLjgfrBczuJyBSxvT5eFJEKwfEBIjI7eJ3/Bsfu\nFZFbxfbAaA28FrzmnkFLoHXQ6vjrwz1oeTxdzDi/I6Kgm4g8JyKTxPZbuC841gdLWF+IyBfBsZNF\n5LvgfXxbRKoU8jqulPNE4ZLRnhHdTu8Hx1YCJ6lqK+B84Ml8ntcLeEJVW2If1EtFpHFw/jHB8Uzg\nokJevyswQ0QqAkOB81X1cKySwbUiUg2rUNtUVZsD90c+WVXfASZh3/xbquq2iIffDZ6b7XysNlVx\n4uwMRJYnuStYkd8cOE5Emqvqk1jF1BNU9QQRqQ7cDZwYvJeTgFsKeR1XyiVlCQ9X6m0LPiwj7QE8\nHfTJZ2IltPP6DrhLRGpj+zD8KiKdsAqqPwblTfak4H0qXhORbcAibE+LhsDCiPpZw4DrsJLV24EX\nRGQ0MDrWf5iqrhKRBUGdnV+xwnTfBNctSpzlsX0VIt+n80SkJ/Z3fQDQBCvfEaldcPyb4HXKY++b\ncwXyROFSxc3ACqz6aRnsgzoXVX1dRL4HTgPGisg1WF2fYap6RwyvcZGqTsq+IyL75XdSUFuoLVZk\nrjtwPVa+OlZvAOcBPwPvq6qKfWrHHCcwGRufeAo4W0TqAbcCbVR1nYgMBSrm81wBPlHVC4oQryvl\nvOvJpYq9geXBZjOXYMXfchGRQ4AFQXfLSKwL5jOgu4jsH5yzn4gcHONr/gLUFZH6wf1LgK+CPv29\nVXUslsDy26N8E1C1gOu+j+00dgGWNChqnEG57H5AOxFpBOwFbAE2iFVH7VJALBOBY7L/TSJSWUTy\na5059xdPFC5VPAtcJiLTsO6aLfmccx4wU0SmAs2wLR9nY33y40RkOvAJ1i1TKFXdjlXXfDuoOpoF\nDMQ+dEcH1/ua/Pv4hwIDswez81x3HVbu+2BV/SE4VuQ4g7GPR4HbVHUaMAVrpbyOdWdlGwx8JCJf\nqOoqbEbW8OB1vsPeT+cK5NVjnXPOReUtCuecc1F5onDOOReVJwrnnHNReaJwzjkXlScK55xzUXmi\ncM45F5UnCuecc1H9PyxN4UbpSmqSAAAAAElFTkSuQmCC\n",
      "text/plain": [
       "<matplotlib.figure.Figure at 0x164bdf8eac8>"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "predictions_validation = rfc.predict_proba(xtest)[:,1]\n",
    "fpr, tpr, _ = roc_curve(ytest, predictions_validation)\n",
    "roc_auc = auc(fpr, tpr)\n",
    "plt.title('ROC Validation')\n",
    "plt.plot(fpr, tpr, 'b', label='AUC = %0.2f' % roc_auc)\n",
    "plt.legend(loc='lower right')\n",
    "plt.plot([0, 1], [0, 1], 'r--')\n",
    "plt.xlim([0, 1])\n",
    "plt.ylim([0, 1])\n",
    "plt.ylabel('True Positive Rate')\n",
    "plt.xlabel('False Positive Rate')\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "collapsed": true
   },
   "source": [
    "### 交叉验证"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "sklearn.model_selection.cross_val_score(estimator, X, y, scoring=None,\n",
    "cv=None, n_jobs=1, verbose=0, fit_params=None, pre_dispatch=‘2*n_jobs’)\n",
    "\n",
    "\n",
    "estimator:   估计方法对象(分类器)\n",
    "\n",
    "X：        数据特征(Features)\n",
    "\n",
    "y：        数据标签(Labels)\n",
    "\n",
    "soring：    调用方法(包括accuracy和mean_squared_error等等)\n",
    "\n",
    "cv：       几折交叉验证\n",
    "\n",
    "n_jobs：   同时工作的cpu个数（-1代表全部）"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 23,
   "metadata": {},
   "outputs": [
    {
     "name": "stderr",
     "output_type": "stream",
     "text": [
      "C:\\Users\\reina\\AppData\\Roaming\\Python\\Python36\\site-packages\\sklearn\\model_selection\\_split.py:1978: FutureWarning: The default value of cv will change from 3 to 5 in version 0.22. Specify it explicitly to silence this warning.\n",
      "  warnings.warn(CV_WARNING, FutureWarning)\n",
      "C:\\Users\\reina\\AppData\\Roaming\\Python\\Python36\\site-packages\\sklearn\\model_selection\\_split.py:1978: FutureWarning: The default value of cv will change from 3 to 5 in version 0.22. Specify it explicitly to silence this warning.\n",
      "  warnings.warn(CV_WARNING, FutureWarning)\n"
     ]
    },
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "0.8589856841784863\n",
      "0.8967035342356681\n"
     ]
    }
   ],
   "source": [
    "clf = DecisionTreeClassifier(max_depth=None, min_samples_split=2,random_state=0)\n",
    "scores = cross_val_score(clf, xtrain, ytrain)\n",
    "print(scores.mean())                             \n",
    "\n",
    "clf2 = RandomForestClassifier(n_estimators=10, max_depth=None,min_samples_split=2, random_state=0)\n",
    "scores = cross_val_score(clf2, xtrain, ytrain)\n",
    "print(scores.mean())                             "
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### 网格搜索选择最优超参数取值"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 24,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "<bound method BaseEstimator.get_params of RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',\n",
       "                       max_depth=None, max_features='auto', max_leaf_nodes=None,\n",
       "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
       "                       min_samples_leaf=1, min_samples_split=2,\n",
       "                       min_weight_fraction_leaf=0.0, n_estimators=10,\n",
       "                       n_jobs=None, oob_score=False, random_state=None,\n",
       "                       verbose=0, warm_start=False)>"
      ]
     },
     "execution_count": 24,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "rfc.get_params"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 25,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "{'n_estimators': 300} 0.8376467254535471\n"
     ]
    }
   ],
   "source": [
    "param_test1 = {'n_estimators': range(25,500,25)}\n",
    "gsearch1 = GridSearchCV(estimator = RandomForestClassifier(min_samples_split=100, \n",
    "                                                           min_samples_leaf=20,\n",
    "                                                           max_depth=8, random_state=10), \n",
    "                        param_grid = param_test1, \n",
    "                        scoring='roc_auc', \n",
    "                        cv=5)\n",
    "gsearch1.fit(xtrain, ytrain)\n",
    "print(gsearch1.best_params_, gsearch1.best_score_)\n",
    "#gsearch1.cv_results_打印拟合结果)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 26,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "{'min_samples_leaf': 10, 'min_samples_split': 60} 0.8457901256625079\n"
     ]
    }
   ],
   "source": [
    "param_test2 = {'min_samples_split':range(60, 200, 20), 'min_samples_leaf':range(10, 110, 10)}\n",
    "gsearch2 = GridSearchCV(estimator = RandomForestClassifier(n_estimators=300,\n",
    "                                                           max_depth=8, random_state=10), \n",
    "                        param_grid = param_test2, \n",
    "                        scoring='roc_auc',\n",
    "                        cv=5)\n",
    "gsearch2.fit(xtrain,ytrain)\n",
    "print(gsearch2.best_params_, gsearch2.best_score_)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 27,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "{'max_depth': 7} 0.8483144059119456\n"
     ]
    }
   ],
   "source": [
    "param_test3 = {'max_depth':range(3, 30, 2)}\n",
    "gsearch3 = GridSearchCV(estimator = RandomForestClassifier(n_estimators=300,\n",
    "                                                           min_samples_split=60, \n",
    "                                                           min_samples_leaf=10,\n",
    "                                                           random_state=10), \n",
    "                        param_grid = param_test3, \n",
    "                        scoring='roc_auc',\n",
    "                        cv=5)\n",
    "gsearch3.fit(xtrain,ytrain)\n",
    "print(gsearch3.best_params_, gsearch3.best_score_)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 28,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.9071946486928104"
      ]
     },
     "execution_count": 28,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "roc_auc_score(ytest, gsearch3.best_estimator_.predict_proba(xtest)[:,1])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 29,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',\n",
       "                       max_depth=7, max_features='auto', max_leaf_nodes=None,\n",
       "                       min_impurity_decrease=0.0, min_impurity_split=None,\n",
       "                       min_samples_leaf=10, min_samples_split=60,\n",
       "                       min_weight_fraction_leaf=0.0, n_estimators=300,\n",
       "                       n_jobs=None, oob_score=False, random_state=10, verbose=0,\n",
       "                       warm_start=False)"
      ]
     },
     "execution_count": 29,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "gsearch3.best_estimator_"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "{'class_weight': None, 'criterion': 'entropy'} 0.8487282683455074\n"
     ]
    }
   ],
   "source": [
    "param_test4 = {'criterion':['gini', 'entropy'], 'class_weight':[None, 'balanced']}\n",
    "gsearch4 = GridSearchCV(estimator = RandomForestClassifier(n_estimators=300,\n",
    "                                                           max_depth=7, \n",
    "                                                           min_samples_split=60, \n",
    "                                                           min_samples_leaf=10,\n",
    "                                                           random_state=10), \n",
    "                        param_grid = param_test4, \n",
    "                        scoring='roc_auc',\n",
    "                        cv=5)\n",
    "gsearch4.fit(xtrain,ytrain)\n",
    "print(gsearch4.best_params_, gsearch4.best_score_)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 31,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.908275462962963"
      ]
     },
     "execution_count": 31,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "roc_auc_score(ytest, gsearch4.best_estimator_.predict_proba(xtest)[:,1])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.6.1"
  },
  "toc": {
   "base_numbering": 1,
   "nav_menu": {},
   "number_sections": true,
   "sideBar": true,
   "skip_h1_title": false,
   "title_cell": "Table of Contents",
   "title_sidebar": "Contents",
   "toc_cell": false,
   "toc_position": {
    "height": "calc(100% - 180px)",
    "left": "10px",
    "top": "150px",
    "width": "273px"
   },
   "toc_section_display": true,
   "toc_window_display": true
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
