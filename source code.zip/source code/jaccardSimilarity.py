import numpy as np
import pandas as pd



def jaccard_Intersection1(association, a, b):
    num = 0
    for i in range(676):
        if association[a, i] != 0:
            for j in range(676):
                if association[a, i] == association[b, j]:
                    num = num + 1
                if association[a, i] < association[b, j]:
                    break
                if association[b, j] == 0:
                    break
        else:
            break
    return num
    
association_matrix = pd.read_csv('output/association_matrix.csv', header=0, encoding='gb18030').values
print("读取数据")
# 100列，676行，每列表示一个病和各rna是否有联系，每行表示一个rna和每个病是否有联系
association_matrix = association_matrix.T
# 转置之后有100行，676列，每行一个disease
disease_associations = np.zeros([100, 676])  # 100种病之间的相似度，初始化矩阵
for i in range(1, 101):
    k = 0
    for j in range(676):
        if association_matrix[i, j] != 0:
            disease_associations[i-1, k] = j + 1
            k = k + 1
disease_JaccardSimilarity = np.zeros([100,100])
print("计算disease_JaccardSimilarity")
for m in range(100):
    num_i = 0
    for n in range(676):
        if disease_associations[m, n] != 0:
            num_i = num_i + 1
        else:
            break
    for i in range(100):
        Intersection = jaccard_Intersection1(disease_associations,m,i);
        num_j = 0
        for n in range(676):
            if disease_associations[i,n] != 0:
                num_j = num_j + 1
            else:
                break
        disease_JaccardSimilarity[m, i] = Intersection / (num_i + num_j - Intersection)

print("保存结果")

result = pd.DataFrame(disease_JaccardSimilarity)
result.to_csv('output/disease_JaccardSimilarity.csv')
# 注意，这样保存之后会多了一行一列行号序号，需要删除


def jaccard_Intersection2(association, a, b):
    num = 0
    for i in range(100):
        if association[a, i] != 0:
            for j in range(100):
                if association[a, i] == association[b, j]:
                    num = num + 1
                if association[a, i] < association[b, j]:
                    break
                if association[b, j] == 0:
                    break
        else:
            break
    return num
    
association_matrix = association_matrix.T
# 转置之后有676行，100列，每行一个circRNA
circRNA_associations = np.zeros([676, 100])  # 100种病之间的相似度，初始化矩阵
for i in range(676):
    k = 0
    for j in range(1, 101):
        if association_matrix[i, j] != 0:
            circRNA_associations[i, k] = j
            k = k + 1
circRNA_JaccardSimilarity = np.zeros([676,676])
print("计算circRNA_JaccardSimilarity")
for m in range(676):
    num_i = 0
    for n in range(100):
        if circRNA_associations[m, n] != 0:
            num_i = num_i + 1
        else:
            break
    for i in range(676):
        Intersection = jaccard_Intersection2(circRNA_associations, m, i);
        num_j = 0
        for n in range(100):
            if circRNA_associations[i,n] != 0:
                num_j = num_j + 1
            else:
                break
        circRNA_JaccardSimilarity[m, i] = Intersection / (num_i + num_j - Intersection)

print("保存结果")

result = pd.DataFrame(circRNA_JaccardSimilarity)
result.to_csv('output/circRNA_JaccardSimilarity.csv')