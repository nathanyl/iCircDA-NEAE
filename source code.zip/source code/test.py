import pandas as pd

data = {
       'disease':['hi',2,5],
       'id':[10,9,8]}

print(data)
df = pd.DataFrame(data)
print(df)

a = df[(df.disease==2)].index.tolist()
b = df[(df.disease==3)].index.tolist()

print(a,b)
if a:
    print("hi")

if b:
    print("b")