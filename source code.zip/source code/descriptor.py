import numpy as np
import pandas as pd
import random

def Search_rna_num(rna, unique_rna):
    for m in range(len(unique_rna)):
        if unique_rna[m] == rna:
            rna_num = m
            break
    return rna_num

def Search_disease_num(disease, unique_disease):
    for n in range(len(unique_disease)):
        if unique_disease[n] == disease:
                disease_num = n
                break
    return disease_num
# 读取数据

uniqueRna_df = pd.read_csv('data/uniqueRna.csv', header=0, encoding='gb18030')
unique_rna = uniqueRna_df['rna'].tolist()

uniqueDisease_df = pd.read_csv('data/uniqueDisease.csv', header=0, encoding='gb18030')
unique_disease = uniqueDisease_df['disease'].tolist()



similarity1 = pd.read_csv('output/similarity1.csv', header=0, encoding='gb18030').values
similarity2 = pd.read_csv('output/similarity2.csv', header=0, encoding='gb18030').values
similarity1 = np.mat(similarity1)
similarity2 = np.mat(similarity2)

# 原始数据会有一行一列是序号，所以要删除，之前读数据的时候已经通过header=0删除了第一行，现在删除第一列，其他类似的操作也是一样目的
similarity1 = np.delete(similarity1, 0, axis=1)
similarity2 = np.delete(similarity2, 0, axis=1)

disease_JaccardSimilarity = pd.read_csv('output/disease_JaccardSimilarity.csv', header=0, encoding='gb18030').values
disease_JaccardSimilarity = np.mat(disease_JaccardSimilarity)
disease_JaccardSimilarity = np.delete(disease_JaccardSimilarity, 0, axis=1)
circRNA_JaccardSimilarity = pd.read_csv('output/circRNA_JaccardSimilarity.csv', header=0, encoding='gb18030').values
circRNA_JaccardSimilarity = np.mat(circRNA_JaccardSimilarity)
circRNA_JaccardSimilarity = np.delete(circRNA_JaccardSimilarity, 0, axis=1)

# print(similarity1.shape)
# 矩阵尺寸为4818行4818列

disease_GaussianSimilarity = pd.read_csv('output/disease_GaussianSimilarity.csv', header=0, encoding='gb18030').values
disease_GaussianSimilarity = np.mat(disease_GaussianSimilarity)
disease_GaussianSimilarity = np.delete(disease_GaussianSimilarity, 0, axis=1)
rna_GaussianSimilarity = pd.read_csv('output/rna_GaussianSimilarity.csv', header=0, encoding='gb18030').values
rna_GaussianSimilarity = np.mat(rna_GaussianSimilarity)
rna_GaussianSimilarity = np.delete(rna_GaussianSimilarity, 0, axis=1)
print(rna_GaussianSimilarity.shape)


meshdisname = pd.read_csv('data/Mesh_disease.csv', header=0, encoding='gb18030')
targetdisease = pd.read_csv('data/uniqueDisease.csv', header=0, encoding='gb18030').values

# 构建descriptor
disease_descriptor = disease_GaussianSimilarity  # 先用circrnadisease计算的相似度作为descriptor，如果两个疾病在MeSH中出现就用MeSh计算的相似度代替


for m in range(len(targetdisease)):
    for n in range(len(targetdisease)):
        mesh_m = meshdisname[(meshdisname.C1 == str(targetdisease[m]))].index.tolist()
        mesh_n = meshdisname[(meshdisname.C1 == str(targetdisease[n]))].index.tolist()
        if mesh_m:
            if mesh_n:
                disease_descriptor[m, n] = (similarity1[mesh_m, mesh_n] + similarity2[mesh_m, mesh_n])*0.5
                print("替换成功")  # 事实证明，两个数据库可能因为命名不统一，根本找不到相同的病

        if m == n:
            disease_descriptor[m, n] = 1

disease_descriptor = np.hstack((disease_descriptor, disease_JaccardSimilarity))

print(disease_descriptor.shape)
# 保存结果
circRNA_descriptor = np.hstack((rna_GaussianSimilarity, circRNA_JaccardSimilarity))

print(circRNA_descriptor.shape)

circRNA_descriptor1 = pd.read_csv('output/circRNA_descriptor1.csv', header=None, encoding='gb18030').values
circRNA_descriptor1 = np.mat(circRNA_descriptor1)
print(circRNA_descriptor1.shape)
association_matrix = pd.read_csv('output/association_matrix.csv', header=0, encoding='gb18030').values
association_matrix = np.delete(association_matrix, 0, axis=1)
association_matrix = association_matrix.T
associations_N = np.zeros([739, 2])
count = 0
while count < 739:
    h = random.randint(0,99)
    l = random.randint(0,675)
    Test = association_matrix[h, l]
    if Test == 0:
        associations_N[count, 1] = h # disease序号
        associations_N[count, 0] = l # rna序号
        count = count + 1
associations = pd.read_csv('data/association.csv', header=0, encoding='gb18030').values

descriptor = np.zeros([739*2, 401])


for i in range(739):
    descriptor[i, 0] = 1
    dis_name = associations[i, 1]
    rna_name = associations[i, 0]
    dis_num = Search_disease_num(dis_name, unique_disease)
    rna_num = Search_rna_num(rna_name, unique_rna)
    count2 = 1
    while count2 < 201:
        descriptor[i, count2] = disease_descriptor[dis_num, count2-1]
        count2 = count2 + 1
    while count2 < 401:
        descriptor[i, count2] = circRNA_descriptor1[rna_num, count2-201]
        count2 = count2 + 1
count1 = 739
while count1 < 1478:
    descriptor[count1, 0] = -1
    dis_num = associations_N[count1-739, 1]
    rna_num = associations_N[count1-739, 0]
    count3 = 1
    while count3 < 201:
        descriptor[count1, count3] = disease_descriptor[int(dis_num), count3-1]
        count3 = count3 + 1
    while count3 < 401:
        descriptor[count1, count3] = circRNA_descriptor1[int(rna_num), count3-201]
        count3 = count3 + 1
    count1 = count1 + 1

print("保存结果")
result = pd.DataFrame(descriptor)
result.to_csv('output/descriptor.csv')
# 注意，这样保存之后会多了一行一列行号序号，需要删除


